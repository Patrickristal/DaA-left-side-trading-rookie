# Changelog

All notable changes to this project will be documented in this file.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/);
versioning follows [SemVer](https://semver.org/).

## [0.1.0] — 2026-05-02

### Initial release

**Skill core (1,800+ 行)**
- SKILL.md: trader profile + 5 core principles + 6 capability modules + composition matrix + module contract spec
- references/forecasting-discipline.md (391 行): Tetlock 10-angle framework — 信号源 #1/#3/#4 + 方法 #2/#5/#6/#7 + 元规则 #8/#9/#10
- references/insight-verification.md: M4 with 3-stage adversarial debate + 5×3 stance matrix + thesis registration mechanism
- references/technical-analysis.md: M2 with 22 named factor registry (Stage / Position / Volume / Momentum / Volatility / Pattern groups)
- references/money-flow-analysis.md: M6 with 3-bucket × 3-dimension grid + FLOW_REGIME_CHANGE alert
- references/policy-analysis.md: M5 with 5-category taxonomy + sector impact lookup
- references/premarket-recap.md: M1 with trend integrity grid + leader identification table
- references/trade-journal-review.md: M3 with 12-tag mistake taxonomy + Dongfang Securities screenshot field mapping

**Helper scripts (3,000+ 行)**
- scripts/akshare_helpers.py: symbol normalization (A-share + HK formats) + safe AKShare invocation + disk cache
- scripts/memory_store.py: active_theses / trade_log / forecasts JSONL stores + Bayesian update audit + Brier-score calibration report
- scripts/ta_factors.py: 22 named TA factors with status-symbol classification (✅/⚠/❌)
- scripts/fund_flow.py: 3-bucket × 3-dimension grid for both A-share (北向/主力/融资) and HK (南向/主力/沽空) markets
- scripts/rs_ranker.py: sector leader ranking with 6-criterion classification (强龙头/二线/跟风)
- scripts/policy_search.py: policy news retrieval with 5-category taxonomy + time-marker / amount extraction + sector impact lookup
- scripts/trend_integrity.py: M1 monitor with 7-type trigger dispatch (factor / ma_break / fund_flow / rs_rank / lhb_seat / policy / manual)
- scripts/xueqiu_fetch.py: Xueqiu sentiment fallback (degraded by default; requires fresh cookies for full access)

**Assets**
- assets/dongfang_screenshot_layout.md: 4 page-type field mappings (持仓/成交/盈亏/K-line) + first-time calibration protocol

**Examples**
- examples/test-1-prediction.md: full markdown output of the canonical prediction test prompt
- examples/test-1-prediction-v2.pdf: 16-page PDF demonstrating polished report layout (cover + TOC + scenario color coding + status badges)
- examples/md_to_pdf.py: CJK-aware markdown-to-PDF renderer used to generate reports

### Design milestones along the way

- **Modular architecture refactor** (Phase 4): mode-based routing → "capability modules" composable across prompts
- **Prediction capability fix** (Phase 4.5): Principle 1 reframed from "no predictions" to "traceable forecasts" with 3-criterion methodology gate
- **Tetlock framework integration** (Phase 4.6): full forecasting-discipline.md added as cross-module methodology
- **Cross-module memory closure** (Phase 5): M4 → M1 → M3 → M4 loop physically implemented via JSONL stores

### Known limitations

- HK real-time quotes are 15-min delayed via AKShare (use broker app for live data)
- 政治局/中央经济工作会议 schedules not in structured form — relies on news_cctv approximation + manual upload
- L2 order book and analyst research reports not accessible
- Xueqiu sentiment scraping is fragile (cookie-dependent); designed to degrade gracefully

### Notes

This is a personal trading skill made for one trader's specific workflow. The
trader profile (capital size, holding style, weakness diagnosis, HK holding
list) is encoded directly in SKILL.md. To adapt to another trader, edit the
"Trader Profile" section in SKILL.md.
