"""md_to_pdf.py v2 — Polished markdown -> PDF converter for da-a-hk-trading reports.

Improvements over v1:
  • Cover page (auto from H1 + metadata bold-prefixed lines)
  • Table of Contents from H1/H2 headings with page numbers
  • Page header (chapter name) + footer (page number)
  • Scenario row color coding (Base = light blue, Bull = light green, Bear = light red)
  • Status symbol coloring in cells (✅ green / ❌ red / ⚠ amber / ↗ ↘ tinted)
  • Zebra striping in non-scenario tables
  • Bold + tinted highlight for percentage / key numeric values
  • Larger heading hierarchy + more breathing room
  • Callout box flowable for key insights
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import Optional

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm, inch, mm
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, NextPageTemplate,
    Paragraph, Spacer, Table, TableStyle, KeepTogether,
    PageBreak, HRFlowable, Flowable,
)
from reportlab.lib.colors import HexColor


# ---------------------------------------------------------------- fonts -----

CJK_FONT_PATH = "/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf"
pdfmetrics.registerFont(TTFont("CJK", CJK_FONT_PATH))

CJK_RE = re.compile(r"[　-〿㐀-䶿一-鿿豈-﫿＀-￯]+")


def wrap_cjk(text):
    return CJK_RE.sub(lambda m: f'<font name="CJK">{m.group(0)}</font>', text)


# ---------------------------------------------------------------- palette ---

PALETTE = {
    "primary":     HexColor("#1f3a68"),  # deep blue, headings
    "accent":      HexColor("#2e6cb6"),
    "muted":       HexColor("#666666"),
    "rule":        HexColor("#cfd6dd"),
    "bg_zebra":    HexColor("#f7f9fb"),
    "bg_header":   HexColor("#e8ecf1"),
    "bg_callout":  HexColor("#fffbe6"),
    "border_callout": HexColor("#ffe58f"),

    # scenario row backgrounds
    "scen_base":   HexColor("#e7f0ff"),  # light blue
    "scen_bull":   HexColor("#e7f9ec"),  # light green
    "scen_bear":   HexColor("#fdeaea"),  # light pink

    # status colors
    "status_ok":   HexColor("#1f8a3a"),
    "status_bad":  HexColor("#c0392b"),
    "status_warn": HexColor("#b8860b"),
    "status_up":   HexColor("#1f8a3a"),
    "status_dn":   HexColor("#c0392b"),

    # number highlight
    "num_pos":     HexColor("#1f8a3a"),
    "num_neg":     HexColor("#c0392b"),
}

# ---------------------------------------------------------------- styles ----

styles = getSampleStyleSheet()


def make_style(name, parent="Normal", **kw):
    base = styles[parent]
    kw.setdefault("fontName", "Helvetica")
    return ParagraphStyle(name=name, parent=base, **kw)


COVER_TITLE = make_style("CoverTitle", "Title", fontName="Helvetica-Bold",
                         fontSize=28, leading=34, textColor=PALETTE["primary"],
                         alignment=TA_LEFT, spaceAfter=18)
COVER_SUBTITLE = make_style("CoverSubtitle", "Normal", fontSize=14, leading=20,
                             textColor=PALETTE["muted"], spaceAfter=8)
COVER_META = make_style("CoverMeta", "Normal", fontSize=10.5, leading=16,
                         textColor=HexColor("#333"), spaceAfter=6)
COVER_TAG = make_style("CoverTag", "Normal", fontSize=9, leading=12,
                        textColor=HexColor("#fff"), backColor=PALETTE["accent"],
                        alignment=TA_CENTER, borderPadding=(3, 7, 3, 7),
                        spaceBefore=2, spaceAfter=2)

H1 = make_style("H1", "Heading1", fontName="Helvetica-Bold", fontSize=20,
                leading=26, spaceAfter=12, spaceBefore=18,
                textColor=PALETTE["primary"])
H2 = make_style("H2", "Heading2", fontName="Helvetica-Bold", fontSize=14.5,
                leading=20, spaceAfter=8, spaceBefore=14,
                textColor=PALETTE["primary"], leftIndent=0,
                borderPadding=(0, 0, 0, 6))
H3 = make_style("H3", "Heading3", fontName="Helvetica-Bold", fontSize=12,
                leading=16, spaceAfter=6, spaceBefore=10,
                textColor=PALETTE["accent"])
H4 = make_style("H4", "Heading4", fontName="Helvetica-Bold", fontSize=10.5,
                leading=14, spaceAfter=4, spaceBefore=8,
                textColor=HexColor("#444"))

BODY = make_style("Body", "Normal", fontSize=10, leading=15, spaceAfter=6,
                  alignment=TA_LEFT, textColor=HexColor("#222"))
QUOTE = make_style("Quote", "Normal", fontSize=10, leading=14.5, spaceAfter=8,
                    leftIndent=14, textColor=PALETTE["muted"])
BULLET = make_style("Bullet", "Normal", fontSize=10, leading=14.5, spaceAfter=2,
                     leftIndent=18, bulletIndent=4)
TOC_LINE = make_style("TOC", "Normal", fontSize=10.5, leading=18,
                       alignment=TA_LEFT, textColor=HexColor("#222"),
                       spaceAfter=2)
TOC_LINE_H2 = make_style("TOC2", "Normal", fontSize=9.5, leading=15,
                          alignment=TA_LEFT, textColor=HexColor("#555"),
                          leftIndent=18, spaceAfter=2)

CELL = make_style("Cell", "Normal", fontSize=8.5, leading=11.5, alignment=TA_LEFT)
CELL_HEADER = make_style("CellH", "Normal", fontName="Helvetica-Bold",
                          fontSize=9, leading=11.5, alignment=TA_LEFT,
                          textColor=HexColor("#111"))


# ------------------------------------------------------ inline conversion ---

# Numeric patterns we want to highlight: percentages, 区间, 万亿, 亿
PCT_RE = re.compile(r"(?<![<>=])(\b\d{1,3}(?:\.\d+)?\s*%(?:\s*[-~–至]\s*\d{1,3}(?:\.\d+)?\s*%)?)")
RANGE_RE = re.compile(r"(\d{4,5}\s*[-~–至到]\s*\d{4,5})")  # e.g. 3300-3700
MONEY_RE = re.compile(r"(\d+(?:\.\d+)?\s*(?:万亿|千亿|亿元|亿))")
PROB_LABEL_RE = re.compile(r"(高\s*\(\>\s*\d+%\)|中\s*\(\d+\s*[-~]\s*\d+%\)|低\s*\(\<\s*\d+%\)|极低\s*\(\<\s*\d+%\))")

# status symbols inline coloring
STATUS_INLINE_MAP = {
    "✅": ("#1f8a3a", True),
    "❌": ("#c0392b", True),
    "⚠": ("#b8860b", True),
    "↗↗": ("#1f8a3a", True),
    "↗": ("#1f8a3a", True),
    "↘↘": ("#c0392b", True),
    "↘": ("#c0392b", True),
}


def _highlight_numerics(text):
    text = PCT_RE.sub(r'<font color="#1f3a68"><b>\1</b></font>', text)
    text = RANGE_RE.sub(r'<font color="#1f3a68"><b>\1</b></font>', text)
    text = MONEY_RE.sub(r'<font color="#1f3a68"><b>\1</b></font>', text)
    text = PROB_LABEL_RE.sub(r'<font color="#1f3a68"><b>\1</b></font>', text)
    return text


def _color_status_symbols(text):
    for sym, (col, bold) in STATUS_INLINE_MAP.items():
        repl = f'<font color="{col}"><b>{sym}</b></font>' if bold else f'<font color="{col}">{sym}</font>'
        text = text.replace(sym, repl)
    return text


def inline(text, highlight_numerics=True):
    """Convert markdown inline syntax to ReportLab Paragraph XML."""
    text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    text = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)
    text = re.sub(r"(?<!\*)\*(?!\s)(.+?)(?<!\s)\*(?!\*)", r"<i>\1</i>", text)
    text = re.sub(r"`([^`]+?)`", r'<font backColor="#f4f4f4">\1</font>', text)
    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\1", text)
    if highlight_numerics:
        text = _highlight_numerics(text)
    text = _color_status_symbols(text)
    text = wrap_cjk(text)
    return text


# ---------------------------------------------------------------- TOC -------

# Bookmarks for TOC; keep page numbers via callback
class TOCEntry(Flowable):
    """Invisible flowable that records its position for TOC."""
    def __init__(self, level, text, key):
        super().__init__()
        self.width = 0; self.height = 0
        self.level = level; self.text = text; self.key = key
    def draw(self):
        self.canv.bookmarkPage(self.key)
        # Outline: flat (level 0) to avoid jump-from-negative errors when body
        # starts at H2. PDF readers still get bookmarks for navigation.
        try:
            self.canv.addOutlineEntry(self.text, self.key, level=0, closed=False)
        except Exception:
            pass


# --------------------------------------------------------- table builders ---

SCENARIO_KEYS = {
    "base": "scen_base",
    "bull": "scen_bull",
    "bear": "scen_bear",
}


def _detect_scenario_key(first_cell_text: str) -> Optional[str]:
    if not first_cell_text:
        return None
    t = first_cell_text.lower()
    t = re.sub(r"[*\s]", "", t)
    t = re.sub(r"<[^>]+>", "", t)  # strip already-applied html tags
    for key in SCENARIO_KEYS:
        if t == key or t.startswith(key):
            return key
    return None


def parse_table(lines, i):
    header = [c.strip() for c in lines[i].strip().strip("|").split("|")]
    sep = lines[i + 1] if i + 1 < len(lines) else ""
    if not re.match(r"^\s*\|?\s*[:\-\s|]+\s*$", sep):
        return None, i
    rows = [header]
    j = i + 2
    while j < len(lines):
        line = lines[j].strip()
        if not line.startswith("|") and "|" not in line:
            break
        if not line:
            break
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        rows.append(cells)
        j += 1
    return rows, j


def build_table(rows):
    if not rows:
        return None
    # Render cells
    data = []
    for r_idx, row in enumerate(rows):
        rendered = []
        for c in row:
            style = CELL_HEADER if r_idx == 0 else CELL
            rendered.append(Paragraph(inline(c, highlight_numerics=(r_idx > 0)), style))
        data.append(rendered)
    n_cols = len(rows[0])
    page_w = A4[0] - 2 * cm * 2
    col_w = page_w / n_cols

    t = Table(data, colWidths=[col_w] * n_cols, repeatRows=1)

    ts = TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("BACKGROUND", (0, 0), (-1, 0), PALETTE["bg_header"]),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 7),
        ("RIGHTPADDING", (0, 0), (-1, -1), 7),
        ("LINEBELOW", (0, 0), (-1, 0), 0.8, PALETTE["primary"]),
        ("LINEBELOW", (0, -1), (-1, -1), 0.4, PALETTE["rule"]),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ])

    # Zebra striping + scenario row coloring
    for r_idx in range(1, len(rows)):
        first_cell = rows[r_idx][0] if rows[r_idx] else ""
        scen = _detect_scenario_key(first_cell)
        if scen:
            ts.add("BACKGROUND", (0, r_idx), (-1, r_idx), PALETTE[SCENARIO_KEYS[scen]])
        elif r_idx % 2 == 0:
            ts.add("BACKGROUND", (0, r_idx), (-1, r_idx), PALETTE["bg_zebra"])

    t.setStyle(ts)
    return t


# ---------------------------------------------------------------- callout ---

class CalloutBox(Flowable):
    """Yellow background, left accent bar, bold first line."""
    def __init__(self, text, width, padding=10):
        super().__init__()
        self.text = text
        self.width = width
        self.padding = padding
        self.para = Paragraph(inline(text), make_style("CalloutInner", "Normal",
                                                       fontSize=10, leading=14))
        _, h = self.para.wrap(width - 2 * padding - 8, 1000)
        self.height = h + 2 * padding
    def draw(self):
        c = self.canv
        c.saveState()
        # bg
        c.setFillColor(PALETTE["bg_callout"])
        c.setStrokeColor(PALETTE["border_callout"])
        c.setLineWidth(0.5)
        c.roundRect(0, 0, self.width, self.height, 4, stroke=1, fill=1)
        # left accent bar
        c.setFillColor(PALETTE["border_callout"])
        c.rect(0, 0, 4, self.height, stroke=0, fill=1)
        c.restoreState()
        self.para.drawOn(c, self.padding + 6, self.padding)


# ------------------------------------------------------------ md -> story ---

def md_to_story_with_toc(md_text: str):
    """Returns (cover_story, toc_story, body_story, headings_for_toc)."""
    lines = md_text.split("\n")

    # ---------- Extract metadata + cover ----------
    cover_title = None
    cover_metas = []
    body_start = 0
    for i, line in enumerate(lines):
        s = line.strip()
        if not s:
            continue
        if s.startswith("# ") and cover_title is None:
            cover_title = s[2:].strip()
            body_start = i + 1
            continue
        if cover_title is not None and s.startswith("**"):
            # collect bold-prefixed metadata lines until first ##
            cover_metas.append(s)
            body_start = i + 1
            continue
        if cover_title is not None:
            # stop at first non-meta line
            break

    cover_story = []
    if cover_title:
        cover_story.append(Spacer(1, 5 * cm))
        cover_story.append(Paragraph(inline(cover_title, highlight_numerics=False), COVER_TITLE))
        cover_story.append(HRFlowable(width="40%", thickness=2,
                                       color=PALETTE["accent"], spaceAfter=18))
        for meta in cover_metas:
            cover_story.append(Paragraph(inline(meta), COVER_META))
        cover_story.append(Spacer(1, 1 * cm))
        # tagline
        cover_story.append(Paragraph(
            "<font color='#666' size='9'>"
            + wrap_cjk("由 da-a-hk-trading-strategist 技能生成") +
            " &middot; Claude Cowork &times; Patrick"
            "</font>",
            COVER_META))
        cover_story.append(NextPageTemplate("body"))
        cover_story.append(PageBreak())

    # ---------- Pre-scan headings for TOC ----------
    headings = []
    body_lines_only = lines[body_start:]
    for ln in body_lines_only:
        s = ln.strip()
        if s.startswith("# "):
            headings.append((1, s[2:].strip()))
        elif s.startswith("## "):
            headings.append((2, s[3:].strip()))

    # ---------- TOC story ----------
    toc_story = []
    if headings:
        toc_story.append(Paragraph("目录", H1))
        toc_story.append(HRFlowable(width="100%", thickness=0.6,
                                     color=PALETTE["rule"], spaceAfter=8))
        for i, (lvl, txt) in enumerate(headings):
            style = TOC_LINE if lvl == 1 else TOC_LINE_H2
            prefix = "■ " if lvl == 1 else "· "
            link = f'<a href="#h_{i}" color="#{PALETTE["accent"].hexval()[2:]}">{prefix}{inline(txt, highlight_numerics=False)}</a>'
            toc_story.append(Paragraph(link, style))
        toc_story.append(NextPageTemplate("body"))
        toc_story.append(PageBreak())

    # ---------- Body ----------
    body = _md_body_to_story(body_lines_only, headings)
    return cover_story, toc_story, body, headings


def _md_body_to_story(lines, headings):
    story = []
    heading_iter = 0
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # Code fence
        if stripped.startswith("```"):
            j = i + 1
            code_lines = []
            while j < len(lines) and not lines[j].strip().startswith("```"):
                code_lines.append(lines[j]); j += 1
            code_style = ParagraphStyle("CodeBlock", parent=styles["Normal"],
                                         fontName="Helvetica", fontSize=8.2,
                                         leading=11, leftIndent=12, rightIndent=12,
                                         spaceAfter=2, spaceBefore=0,
                                         backColor=HexColor("#f5f7fa"),
                                         borderPadding=4, textColor=HexColor("#333"))
            for cline in "\n".join(code_lines).split("\n"):
                xml = cline.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                xml = xml.replace(" ", "&nbsp;")
                xml = wrap_cjk(xml)
                if not xml: xml = "&nbsp;"
                story.append(Paragraph(xml, code_style))
            story.append(Spacer(1, 6))
            i = j + 1; continue

        # Headings — anchor for TOC
        if stripped.startswith("# "):
            text = stripped[2:].strip()
            anchor_key = f"h_{heading_iter}"; heading_iter += 1
            story.append(TOCEntry(1, text, anchor_key))
            story.append(Paragraph(f'<a name="{anchor_key}"/>{inline(text, highlight_numerics=False)}', H1))
            story.append(HRFlowable(width="100%", thickness=0.5,
                                     color=PALETTE["rule"], spaceAfter=4))
            i += 1; continue
        if stripped.startswith("## "):
            text = stripped[3:].strip()
            anchor_key = f"h_{heading_iter}"; heading_iter += 1
            story.append(TOCEntry(2, text, anchor_key))
            story.append(Paragraph(f'<a name="{anchor_key}"/>{inline(text, highlight_numerics=False)}', H2))
            i += 1; continue
        if stripped.startswith("### "):
            story.append(Paragraph(inline(stripped[4:], highlight_numerics=False), H3))
            i += 1; continue
        if stripped.startswith("#### "):
            story.append(Paragraph(inline(stripped[5:], highlight_numerics=False), H4))
            i += 1; continue

        # HR
        if stripped in ("---", "***", "___"):
            story.append(HRFlowable(width="100%", thickness=0.4,
                                     color=PALETTE["rule"], spaceBefore=4, spaceAfter=8))
            i += 1; continue

        # Table
        if stripped.startswith("|") and i + 1 < len(lines) and re.match(r"^\s*\|?\s*[:\-\s|]+\s*$", lines[i + 1]):
            rows, new_i = parse_table(lines, i)
            if rows:
                t = build_table(rows)
                if t:
                    story.append(t); story.append(Spacer(1, 8))
                i = new_i; continue

        # Block quote -> callout box
        if stripped.startswith("> "):
            quote_lines = []
            while i < len(lines) and lines[i].strip().startswith("> "):
                quote_lines.append(lines[i].strip()[2:]); i += 1
            text = " ".join(quote_lines)
            page_w = A4[0] - 2 * cm * 2
            try:
                story.append(CalloutBox(text, page_w))
                story.append(Spacer(1, 6))
            except Exception:
                story.append(Paragraph(inline(text), QUOTE))
            continue

        # Unordered list
        if stripped.startswith(("- ", "* ", "+ ")):
            items = []
            while i < len(lines) and lines[i].strip().startswith(("- ", "* ", "+ ")):
                items.append(lines[i].strip()[2:]); i += 1
            for item in items:
                story.append(Paragraph("•&nbsp; " + inline(item), BULLET))
            continue

        # Ordered list
        if re.match(r"^\d+\.\s", stripped):
            items = []
            while i < len(lines) and re.match(r"^\d+\.\s", lines[i].strip()):
                items.append(re.sub(r"^\d+\.\s", "", lines[i].strip())); i += 1
            for k, item in enumerate(items, 1):
                story.append(Paragraph(f"{k}.&nbsp; " + inline(item), BULLET))
            continue

        if not stripped:
            i += 1; continue

        # Paragraph
        para = []
        while i < len(lines) and lines[i].strip() and not (
            lines[i].strip().startswith(("# ", "## ", "### ", "#### ", "- ", "* ", "+ ", "> ", "```", "|"))
            or re.match(r"^\d+\.\s", lines[i].strip())
            or lines[i].strip() in ("---", "***", "___")
        ):
            para.append(lines[i].strip()); i += 1
        if para:
            story.append(Paragraph(inline(" ".join(para)), BODY))

    return story


# ----------------------------------------------------- doc / page templates -

class ReportDocTemplate(BaseDocTemplate):
    def __init__(self, filename, doc_title="", **kw):
        super().__init__(filename, **kw)
        self.doc_title = doc_title
        self.current_h1 = ""

        # frame for cover (no header/footer)
        cover_frame = Frame(2 * cm, 2 * cm,
                             A4[0] - 4 * cm, A4[1] - 4 * cm,
                             id="cover_frame", showBoundary=0)
        # frame for body (with header/footer)
        body_frame = Frame(2 * cm, 2 * cm,
                            A4[0] - 4 * cm, A4[1] - 3.6 * cm,
                            id="body_frame", showBoundary=0)

        self.addPageTemplates([
            PageTemplate(id="cover", frames=[cover_frame], onPage=self._cover_decoration),
            PageTemplate(id="body", frames=[body_frame],
                          onPage=self._body_header_footer),
        ])

    def _cover_decoration(self, canv, doc):
        canv.saveState()
        # bottom bar
        canv.setFillColor(PALETTE["primary"])
        canv.rect(0, 0, A4[0], 6 * mm, stroke=0, fill=1)
        # top thin bar
        canv.setFillColor(PALETTE["accent"])
        canv.rect(0, A4[1] - 4 * mm, A4[0], 4 * mm, stroke=0, fill=1)
        canv.restoreState()

    def _body_header_footer(self, canv, doc):
        canv.saveState()
        # header — keep ASCII-only because Helvetica has no CJK glyphs
        # and Droid Sans Fallback has no Latin glyphs; mixing them in
        # canvas.drawString isn't supported.
        canv.setFont("Helvetica", 8.5)
        canv.setFillColor(PALETTE["muted"])
        canv.drawString(2 * cm, A4[1] - 1.2 * cm, "da-a-hk-trading-strategist · prediction report")
        canv.drawRightString(A4[0] - 2 * cm, A4[1] - 1.2 * cm, f"p {canv.getPageNumber()}")
        # header rule
        canv.setStrokeColor(PALETTE["rule"])
        canv.setLineWidth(0.4)
        canv.line(2 * cm, A4[1] - 1.4 * cm, A4[0] - 2 * cm, A4[1] - 1.4 * cm)
        # footer
        canv.setFont("Helvetica", 8)
        canv.drawCentredString(A4[0] / 2, 1.2 * cm,
                                "Patrick x Claude Cowork - confidential analysis")
        canv.restoreState()


# ----------------------------------------------------------------- main -----

def convert(md_path: Path, pdf_path: Path):
    md_text = md_path.read_text(encoding="utf-8")

    # First H1 becomes doc title for header
    m = re.search(r"^#\s+(.+)$", md_text, re.MULTILINE)
    doc_title = m.group(1).strip() if m else ""

    cover, toc, body, _ = md_to_story_with_toc(md_text)

    doc = ReportDocTemplate(
        str(pdf_path), doc_title=doc_title,
        pagesize=A4, title=doc_title,
        author="da-a-hk-trading-strategist",
    )
    story = []
    if cover:
        story.extend(cover)
    if toc:
        story.extend(toc)
    story.extend(body)
    doc.build(story)
    print(f"✅ PDF generated: {pdf_path}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("input", help="markdown file")
    p.add_argument("output", help="pdf file")
    args = p.parse_args()
    convert(Path(args.input), Path(args.output))


if __name__ == "__main__":
    main()
