"""
da-a-hk-trading skill — helper scripts.

These scripts are invoked by Claude when the skill is active. Each script can be:
  1. Imported as a module:        from scripts.ta_factors import compute_factors
  2. Run as CLI for stdout JSON:  python -m scripts.ta_factors --symbol 600519

Layered architecture:
  akshare_helpers.py    — base data layer (symbol normalization, safe API calls, cache)
  memory_store.py       — base persistence (active_theses / trade_log / forecasts jsonl)
  ta_factors.py         — M2 named factor registry
  fund_flow.py          — M6 three-bucket × three-dimension grid
  rs_ranker.py          — M1+M2 sector leader ranking
  policy_search.py      — M5 policy retrieval
  xueqiu_fetch.py       — M6 Xueqiu sentiment (stub; community scraper)
  trend_integrity.py    — M1 trend-break trigger checker
  forecasts.py          — forecast logging + Brier score calibration
"""
__version__ = "0.1.0"
