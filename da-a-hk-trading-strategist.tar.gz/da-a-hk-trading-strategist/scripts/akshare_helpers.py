"""
akshare_helpers.py — base data layer for the da-a-hk-trading skill.

Responsibilities:
  - Normalize symbol formats across A-share (600519 / sh600519 / SZ300750)
    and HK (00700 / 700 / 0700.HK) markets.
  - Wrap AKShare calls with error handling, timeout, and on-disk cache so the
    skill doesn't hammer public endpoints during a single Claude session.
  - Provide simple, named accessors for the most-used data points:
      OHLCV (A-share + HK)
      Index history (上证 / 沪深300 / 恒生 / 恒生科技 / 创业板)
      Sector indices and constituents
      News flow (CCTV + 财联社)
      Margin trading
      Hot board (industry / concept)
  - Return clean dicts / pandas DataFrames; never raise raw AKShare errors at
    the caller — wrap them in a friendly result envelope so the LLM can read
    the failure and react.

Usage from Python:
    from scripts.akshare_helpers import fetch_ohlcv, normalize_symbol
    df = fetch_ohlcv("600519", market="A", period="daily", days=120)

Usage from CLI:
    python -m scripts.akshare_helpers ohlcv --symbol 600519 --market A --days 60
    python -m scripts.akshare_helpers news --date 20260501

CLI emits JSON to stdout so the calling agent can `json.load` directly.

Data source: AKShare (https://akshare.akfamily.xyz/). No auth required, but
public endpoints are rate-throttled — rely on the cache.
"""
from __future__ import annotations

import argparse
import functools
import hashlib
import json
import os
import re
import sys
import time
from dataclasses import dataclass, asdict
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Optional


# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------

CACHE_DIR = Path(os.environ.get("DA_A_HK_CACHE_DIR", "~/.cache/da-a-hk-trading")).expanduser()
CACHE_TTL_SECONDS = int(os.environ.get("DA_A_HK_CACHE_TTL", "3600"))  # 1 hour default
DEFAULT_TIMEOUT = 20  # seconds per AKShare call


def _cache_path(key: str) -> Path:
    h = hashlib.sha1(key.encode("utf-8")).hexdigest()[:16]
    return CACHE_DIR / f"{h}.json"


def cached(ttl: int = CACHE_TTL_SECONDS):
    """Disk-cache decorator. Caches the JSON-serializable return value
    for `ttl` seconds keyed by function name + args."""
    def decorator(func: Callable):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            CACHE_DIR.mkdir(parents=True, exist_ok=True)
            key = f"{func.__name__}({args},{sorted(kwargs.items())})"
            path = _cache_path(key)
            if path.exists():
                age = time.time() - path.stat().st_mtime
                if age < ttl:
                    try:
                        return json.loads(path.read_text(encoding="utf-8"))
                    except Exception:
                        pass  # fall through to live call
            result = func(*args, **kwargs)
            try:
                path.write_text(json.dumps(result, ensure_ascii=False, default=str), encoding="utf-8")
            except Exception:
                pass  # cache write failures are non-fatal
            return result
        return wrapper
    return decorator


# --------------------------------------------------------------------------
# Symbol normalization
# --------------------------------------------------------------------------

@dataclass
class Symbol:
    """Normalized representation of a stock symbol."""
    raw: str           # original input
    market: str        # "A" | "HK" | "US"
    code: str          # bare numeric/alpha code: "600519", "00700", "AAPL"
    em_format: str     # East Money format used by AKShare: "600519", "00700"
    sina_format: str   # Sina format: "sh600519", "sz300750", "hk00700"
    exchange: str      # "SH" | "SZ" | "BJ" | "HK" | "US"
    name: Optional[str] = None  # filled later if looked up

    def to_dict(self) -> dict:
        return asdict(self)


_HK_RE = re.compile(r"^(hk)?0*(\d{1,5})(\.hk)?$", re.IGNORECASE)
_A_RE = re.compile(r"^(sh|sz|bj)?(\d{6})(\.(sh|sz|bj))?$", re.IGNORECASE)


def normalize_symbol(raw: str, market: Optional[str] = None) -> Symbol:
    """Parse a symbol string into a normalized Symbol object.

    Handles:
      A-share: "600519", "sh600519", "300750", "SZ300750", "600519.SH"
      HK:      "00700", "700", "0700.HK", "hk00700", "00700.hk"

    `market` hint disambiguates ambiguous inputs (e.g. "00700" looks like HK
    but a 6-digit number could also be A-share).
    """
    s = raw.strip()

    # Explicit market hint — try that first
    if market and market.upper() == "HK":
        m = _HK_RE.match(s)
        if m:
            code = m.group(2).zfill(5)
            return Symbol(raw=raw, market="HK", code=code,
                          em_format=code, sina_format=f"hk{code}", exchange="HK")
    if market and market.upper() == "A":
        m = _A_RE.match(s)
        if m:
            code = m.group(2)
            exchange = (m.group(1) or m.group(4) or _infer_a_exchange(code)).upper()
            return Symbol(raw=raw, market="A", code=code,
                          em_format=code, sina_format=f"{exchange.lower()}{code}",
                          exchange=exchange)

    # No explicit hint — auto-detect
    # A-share: 6-digit numeric code
    m = _A_RE.match(s)
    if m and len(m.group(2)) == 6:
        code = m.group(2)
        exchange = (m.group(1) or m.group(4) or _infer_a_exchange(code)).upper()
        return Symbol(raw=raw, market="A", code=code,
                      em_format=code, sina_format=f"{exchange.lower()}{code}",
                      exchange=exchange)

    # HK: shorter code, possibly with hk prefix or .hk suffix
    m = _HK_RE.match(s)
    if m:
        code = m.group(2).zfill(5)
        return Symbol(raw=raw, market="HK", code=code,
                      em_format=code, sina_format=f"hk{code}", exchange="HK")

    raise ValueError(f"Cannot parse symbol: {raw!r}. Provide market='A' or 'HK' explicitly.")


def _infer_a_exchange(code: str) -> str:
    """Guess SH / SZ / BJ from a 6-digit A-share code."""
    if code.startswith(("60", "688", "900")):  # 60x main, 688 STAR, 900 B-share SH
        return "SH"
    if code.startswith(("00", "30", "200")):   # 00x main+SME, 30x ChiNext, 200 B-share SZ
        return "SZ"
    if code.startswith(("8", "4")):             # 北交所
        return "BJ"
    return "SH"  # fallback


# --------------------------------------------------------------------------
# Safe AKShare invocation
# --------------------------------------------------------------------------

def _safe_call(func_name: str, **kwargs) -> dict:
    """Invoke akshare.<func_name>(**kwargs) safely. Returns a result envelope:
       {"ok": True, "data": <records>}  or  {"ok": False, "error": <message>}
    Uses dynamic import so akshare is only required when actually used.
    """
    try:
        import akshare as ak  # noqa
    except ImportError:
        return {"ok": False, "error": "akshare not installed. Run: pip install akshare>=1.18"}

    try:
        func = getattr(ak, func_name, None)
        if func is None:
            return {"ok": False, "error": f"AKShare has no function {func_name!r}"}
        df = func(**kwargs)
        # AKShare returns pandas.DataFrame; convert to records for JSON
        if hasattr(df, "to_dict"):
            records = df.to_dict(orient="records")
        else:
            records = df
        return {"ok": True, "data": records, "n_rows": len(records) if hasattr(records, "__len__") else None}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}", "func": func_name, "kwargs": kwargs}


# --------------------------------------------------------------------------
# Public accessors
# --------------------------------------------------------------------------

@cached(ttl=3600)
def fetch_ohlcv(symbol: str, market: Optional[str] = None,
                period: str = "daily", days: int = 120,
                adjust: str = "qfq") -> dict:
    """Fetch OHLCV history. Returns envelope with `data` = list of dicts.

    `period`: "daily" | "weekly" | "monthly"
    `days`:   number of trading days to look back from today
    `adjust`: "qfq" (front-adjusted, default for TA) | "hfq" | "" (raw)
    """
    sym = normalize_symbol(symbol, market)
    end = date.today().strftime("%Y%m%d")
    start = (date.today() - timedelta(days=days * 2)).strftime("%Y%m%d")  # 2x for non-trading days

    if sym.market == "A":
        return _safe_call("stock_zh_a_hist",
                          symbol=sym.em_format, period=period,
                          start_date=start, end_date=end, adjust=adjust)
    elif sym.market == "HK":
        return _safe_call("stock_hk_hist",
                          symbol=sym.em_format, period=period,
                          start_date=start, end_date=end, adjust=adjust)
    else:
        return {"ok": False, "error": f"Unsupported market {sym.market}"}


@cached(ttl=3600)
def fetch_index_hist(index_name: str, days: int = 250) -> dict:
    """Fetch index history. `index_name` accepts friendly names:
       sh000001 / 上证 | 000300 / 沪深300 | sz399001 / 深证 | sz399006 / 创业板
       hsi / 恒生 | hstech / 恒生科技
    """
    aliases = {
        "上证": "sh000001", "shcomp": "sh000001",
        "沪深300": "sh000300", "csi300": "sh000300",
        "深证": "sz399001", "szcomp": "sz399001",
        "创业板": "sz399006", "chinext": "sz399006",
        "科创50": "sh000688",
        "恒生": "HSI", "hsi": "HSI",
        "恒生科技": "HSTECH", "hstech": "HSTECH",
        "国企": "HSCEI", "hscei": "HSCEI",
    }
    sym = aliases.get(index_name.lower(), index_name)
    end = date.today().strftime("%Y%m%d")
    start = (date.today() - timedelta(days=days * 2)).strftime("%Y%m%d")
    if sym.startswith(("sh", "sz")):
        return _safe_call("stock_zh_index_daily_em", symbol=sym)
    else:
        # HK indices via dedicated function
        return _safe_call("stock_hk_index_daily_em", symbol=sym)


@cached(ttl=1800)
def fetch_realtime_a_spot() -> dict:
    """All A-share real-time quotes (15-min delay during market hours)."""
    return _safe_call("stock_zh_a_spot_em")


@cached(ttl=1800)
def fetch_realtime_hk_spot() -> dict:
    """All HK real-time quotes (15-min delay during market hours)."""
    return _safe_call("stock_hk_spot_em")


@cached(ttl=600)
def fetch_industry_boards() -> dict:
    """All industry boards (申万二级 + 东方财富 行业)."""
    return _safe_call("stock_board_industry_name_em")


@cached(ttl=600)
def fetch_concept_boards() -> dict:
    """All concept boards (东方财富 概念)."""
    return _safe_call("stock_board_concept_name_em")


@cached(ttl=600)
def fetch_concept_boards_ths() -> dict:
    """Tonghuashun concept boards (more complete than EM, no 200-row cap)."""
    return _safe_call("stock_board_concept_name_ths")


@cached(ttl=1800)
def fetch_industry_constituents(industry_name: str) -> dict:
    """Constituents of an industry board (e.g. '储能设备', '半导体')."""
    return _safe_call("stock_board_industry_cons_em", symbol=industry_name)


@cached(ttl=1800)
def fetch_concept_constituents(concept_name: str) -> dict:
    """Constituents of a concept board."""
    return _safe_call("stock_board_concept_cons_em", symbol=concept_name)


@cached(ttl=900)
def fetch_news_cctv(target_date: Optional[str] = None) -> dict:
    """新闻联播 transcripts. `target_date` format YYYYMMDD; default today."""
    target_date = target_date or date.today().strftime("%Y%m%d")
    return _safe_call("news_cctv", date=target_date)


@cached(ttl=300)
def fetch_news_cls() -> dict:
    """财联社电报 (recent 12 hours of market-moving headlines)."""
    return _safe_call("stock_info_global_cls")


@cached(ttl=900)
def fetch_individual_info(symbol: str, market: str = "A") -> dict:
    """Static info for a stock: industry, listing date, total shares, etc."""
    sym = normalize_symbol(symbol, market)
    if sym.market == "A":
        return _safe_call("stock_individual_info_em", symbol=sym.em_format)
    return {"ok": False, "error": "HK static info uses different endpoints; not implemented"}


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def _emit(obj: Any) -> None:
    """Print JSON to stdout for LLM consumption."""
    print(json.dumps(obj, ensure_ascii=False, default=str, indent=2))


def main():
    p = argparse.ArgumentParser(prog="akshare_helpers", description="Base AKShare data fetchers")
    sub = p.add_subparsers(dest="cmd", required=True)

    p_ohlcv = sub.add_parser("ohlcv", help="Fetch OHLCV history")
    p_ohlcv.add_argument("--symbol", required=True)
    p_ohlcv.add_argument("--market", choices=["A", "HK"], default=None)
    p_ohlcv.add_argument("--period", default="daily")
    p_ohlcv.add_argument("--days", type=int, default=120)
    p_ohlcv.add_argument("--adjust", default="qfq")

    p_idx = sub.add_parser("index", help="Fetch index history")
    p_idx.add_argument("--name", required=True, help="上证 / 沪深300 / 恒生 / etc.")
    p_idx.add_argument("--days", type=int, default=250)

    p_news = sub.add_parser("news", help="Fetch news (CCTV / CLS)")
    p_news.add_argument("--source", choices=["cctv", "cls"], default="cls")
    p_news.add_argument("--date", default=None, help="YYYYMMDD for CCTV")

    p_norm = sub.add_parser("normalize", help="Normalize symbol")
    p_norm.add_argument("--symbol", required=True)
    p_norm.add_argument("--market", choices=["A", "HK"], default=None)

    p_board = sub.add_parser("boards", help="List industry / concept boards")
    p_board.add_argument("--type", choices=["industry", "concept", "concept_ths"], default="industry")

    args = p.parse_args()

    if args.cmd == "ohlcv":
        _emit(fetch_ohlcv(args.symbol, args.market, args.period, args.days, args.adjust))
    elif args.cmd == "index":
        _emit(fetch_index_hist(args.name, args.days))
    elif args.cmd == "news":
        if args.source == "cctv":
            _emit(fetch_news_cctv(args.date))
        else:
            _emit(fetch_news_cls())
    elif args.cmd == "normalize":
        _emit(normalize_symbol(args.symbol, args.market).to_dict())
    elif args.cmd == "boards":
        if args.type == "industry":
            _emit(fetch_industry_boards())
        elif args.type == "concept":
            _emit(fetch_concept_boards())
        else:
            _emit(fetch_concept_boards_ths())


if __name__ == "__main__":
    main()
