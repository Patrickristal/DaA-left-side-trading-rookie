"""
fund_flow.py — M6 三资金趋势分析 (Three Money Trends).

Implements the 3 buckets × 3 dimensions grid:

    Buckets (A-share):  北向 (northbound) / 主力 (main capital) / 融资融券 (margin)
    Buckets (HK):       南向 (southbound) / 主力 / 沽空 (short ratio, inverse)
    Dimensions:         量 (amount) / 向 (direction over 5d, 20d) / 速 (velocity Z-score)

Key alert rule: FLOW_REGIME_CHANGE fires when ≥ 2 buckets show same-direction
velocity with |z| ≥ 1.5 — this is the cross-bucket resonance signal that
practitioners trust more than any single bucket reading.

Usage:
    from scripts.fund_flow import compute_three_bucket_grid
    g = compute_three_bucket_grid(target="600519", target_type="stock", market="A")

CLI:
    python -m scripts.fund_flow --target 600519 --type stock --market A
    python -m scripts.fund_flow --target "储能设备" --type industry --market A
    python -m scripts.fund_flow --target all --type market --market A
"""
from __future__ import annotations

import argparse
import json
import sys
from typing import Optional

try:
    import numpy as np
    import pandas as pd
except ImportError:
    print(json.dumps({"ok": False, "error": "numpy and pandas required"}))
    sys.exit(1)


# --------------------------------------------------------------------------
# Velocity Z-score classification
# --------------------------------------------------------------------------

def _velocity_status(z: float) -> tuple[str, str]:
    """Map Z-score to status symbol + label."""
    if pd.isna(z):
        return "?", "数据缺"
    if z >= 2.0:
        return "↗↗", "显著加速流入"
    if z >= 1.0:
        return "↗", "温和加速"
    if z <= -2.0:
        return "↘↘", "显著加速流出"
    if z <= -1.0:
        return "↘", "温和减速"
    return "→", "常态"


def _amount_status(amount_5d: float, amount_20d: float) -> tuple[str, str]:
    """Direction status from 5d and 20d cumulative."""
    if pd.isna(amount_5d) or pd.isna(amount_20d):
        return "?", "数据缺"
    sign5 = np.sign(amount_5d)
    sign20 = np.sign(amount_20d)
    if sign5 > 0 and sign20 > 0:
        return "✅", "5日 + 20日 同向流入"
    if sign5 < 0 and sign20 < 0:
        return "❌", "5日 + 20日 同向流出"
    if sign5 > 0 and sign20 < 0:
        return "⚠", "5日转入但 20日仍出（拐点观察）"
    if sign5 < 0 and sign20 > 0:
        return "⚠", "5日转出但 20日仍入（警戒）"
    return "→", "撕裂或中性"


# --------------------------------------------------------------------------
# Bucket fetchers
# --------------------------------------------------------------------------

def _fetch_a_individual_flow(symbol: str) -> dict:
    """Per-stock 主力资金 flow time series. Returns DataFrame in dict."""
    from scripts.akshare_helpers import _safe_call, normalize_symbol
    sym = normalize_symbol(symbol, "A")
    market = sym.exchange.lower() if sym.exchange in ("SH", "SZ") else "sh"
    return _safe_call("stock_individual_fund_flow", stock=sym.em_format, market=market)


def _fetch_a_market_flow() -> dict:
    """Whole-market 主力 flow time series."""
    from scripts.akshare_helpers import _safe_call
    return _safe_call("stock_market_fund_flow")


def _fetch_a_sector_flow_summary(industry: str) -> dict:
    """Industry-level 主力 flow."""
    from scripts.akshare_helpers import _safe_call
    return _safe_call("stock_sector_fund_flow_summary", symbol=industry, indicator="今日")


def _fetch_northbound_hist() -> dict:
    """北向资金 historical net flow."""
    from scripts.akshare_helpers import _safe_call
    return _safe_call("stock_hsgt_hist_em", symbol="北向资金")


def _fetch_southbound_hist() -> dict:
    """南向资金 historical net flow (for HK)."""
    from scripts.akshare_helpers import _safe_call
    return _safe_call("stock_hsgt_hist_em", symbol="南向资金")


def _fetch_northbound_individual(symbol: str) -> dict:
    """Per-stock 北向 holdings."""
    from scripts.akshare_helpers import _safe_call, normalize_symbol
    sym = normalize_symbol(symbol, "A")
    return _safe_call("stock_hsgt_individual_em", stock=sym.em_format)


def _fetch_margin_total() -> dict:
    """SSE + SZSE margin trading total balance."""
    from scripts.akshare_helpers import _safe_call
    sse = _safe_call("stock_margin_sse")
    szse = _safe_call("stock_margin_szse", date="")
    return {"ok": True, "sse": sse, "szse": szse}


def _fetch_lhb(start_date: str, end_date: str) -> dict:
    """龙虎榜 详细数据."""
    from scripts.akshare_helpers import _safe_call
    return _safe_call("stock_lhb_detail_em", start_date=start_date, end_date=end_date)


# --------------------------------------------------------------------------
# Core: compute the 3×3 grid
# --------------------------------------------------------------------------

def _compute_bucket_metrics(series: pd.Series) -> dict:
    """Given a daily flow series (most recent at end), compute amount/direction/velocity."""
    if series is None or len(series) < 21:
        return {"amount_5d_yi": None, "amount_20d_yi": None,
                "velocity_z": None, "velocity_status": ("?", "样本<21日")}
    s = pd.to_numeric(series, errors="coerce").dropna()
    if len(s) < 21:
        return {"amount_5d_yi": None, "amount_20d_yi": None,
                "velocity_z": None, "velocity_status": ("?", "有效样本<21日")}
    today_net = s.iloc[-1]
    last_20 = s.iloc[-21:-1]
    mean20 = last_20.mean()
    std20 = last_20.std(ddof=1)
    z = (today_net - mean20) / std20 if std20 and not pd.isna(std20) else None
    sym, label = _velocity_status(z if z is not None else float("nan"))
    return {
        "today_net_yi": round(float(today_net) / 1e8, 2),  # convert to 亿元
        "amount_5d_yi": round(float(s.iloc[-5:].sum()) / 1e8, 2),
        "amount_20d_yi": round(float(s.iloc[-20:].sum()) / 1e8, 2),
        "velocity_z": round(float(z), 2) if z is not None else None,
        "velocity_status": (sym, label),
    }


def _bucket_to_grid_row(name: str, metrics: dict) -> dict:
    """Format one bucket row for output."""
    if metrics.get("amount_5d_yi") is None:
        amount_status = ("?", "数据缺")
    else:
        amount_status = _amount_status(metrics["amount_5d_yi"], metrics["amount_20d_yi"])
    sym, vlab = metrics.get("velocity_status", ("?", "?"))
    return {
        "bucket": name,
        "today_net_yi": metrics.get("today_net_yi"),
        "amount_5d_yi": metrics.get("amount_5d_yi"),
        "amount_20d_yi": metrics.get("amount_20d_yi"),
        "direction_status": amount_status[0],
        "direction_note": amount_status[1],
        "velocity_z": metrics.get("velocity_z"),
        "velocity_status": sym,
        "velocity_note": vlab,
    }


def _detect_flow_regime_change(grid: list[dict]) -> Optional[dict]:
    """FLOW_REGIME_CHANGE: ≥ 2 buckets with |velocity_z| ≥ 1.5 same direction."""
    accel_in = [r for r in grid if r["velocity_z"] is not None and r["velocity_z"] >= 1.5]
    accel_out = [r for r in grid if r["velocity_z"] is not None and r["velocity_z"] <= -1.5]
    if len(accel_in) >= 2:
        return {
            "alert": "FLOW_REGIME_CHANGE",
            "direction": "加速流入",
            "buckets": [r["bucket"] for r in accel_in],
            "z_scores": [r["velocity_z"] for r in accel_in],
            "interpretation": "跨桶共振：方向较确定，趋势可能延续",
        }
    if len(accel_out) >= 2:
        return {
            "alert": "FLOW_REGIME_CHANGE",
            "direction": "加速流出",
            "buckets": [r["bucket"] for r in accel_out],
            "z_scores": [r["velocity_z"] for r in accel_out],
            "interpretation": "跨桶共振：常见于趋势顶部 / 风险释放",
        }
    return None


# --------------------------------------------------------------------------
# Top-level entry points
# --------------------------------------------------------------------------

def _series_from_records(records: list[dict], col_candidates: list[str]) -> Optional[pd.Series]:
    """Find the right net-flow column from AKShare records."""
    if not records:
        return None
    df = pd.DataFrame(records)
    for c in col_candidates:
        if c in df.columns:
            # Sort by date if there's a date column
            for date_col in ("日期", "date", "日期 "):
                if date_col in df.columns:
                    df = df.sort_values(date_col)
                    break
            return df[c].reset_index(drop=True)
    return None


def compute_three_bucket_grid(target: str, target_type: str = "stock",
                                market: str = "A") -> dict:
    """Main entry point.

    target_type: "stock" | "industry" | "concept" | "market"
    market: "A" | "HK"
    """
    grid: list[dict] = []

    if market == "A":
        # ---------- 北向 bucket ----------
        nb = _fetch_northbound_hist()
        if nb.get("ok"):
            # AKShare returns columns like '日期', '当日成交净买额', '历史累计净买额'
            series = _series_from_records(nb["data"], ["当日成交净买额", "净买额", "今日资金净流入"])
            if series is not None:
                # AKShare unit is 万元, convert to 元
                metrics = _compute_bucket_metrics(series * 10000 if series.abs().median() < 1e6 else series)
                grid.append(_bucket_to_grid_row("北向", metrics))
            else:
                grid.append({"bucket": "北向", "error": "未找到净买额列"})
        else:
            grid.append({"bucket": "北向", "error": nb.get("error")})

        # ---------- 主力 bucket ----------
        if target_type == "stock":
            mf = _fetch_a_individual_flow(target)
            col_candidates = ["主力净流入-净额", "主力净流入", "主力净额"]
        elif target_type == "industry":
            mf = _fetch_a_sector_flow_summary(target)
            col_candidates = ["主力净流入-净额", "主力净流入"]
        else:  # market
            mf = _fetch_a_market_flow()
            col_candidates = ["主力净流入-净额", "主力净流入"]

        if mf.get("ok"):
            series = _series_from_records(mf["data"], col_candidates)
            if series is not None:
                metrics = _compute_bucket_metrics(series)
                grid.append(_bucket_to_grid_row("主力", metrics))
            else:
                grid.append({"bucket": "主力", "error": "未找到主力净流入列"})
        else:
            grid.append({"bucket": "主力", "error": mf.get("error")})

        # ---------- 融资融券 bucket ----------
        margin = _fetch_margin_total()
        # Margin reading is harder to get a clean daily net; provide a placeholder
        # marking — production version should compute net change of融资余额
        grid.append({
            "bucket": "融资融券",
            "note": "需补充：融资余额日变动 / 个股 stock_margin_detail_*; 当前仅返回总余额数据",
            "today_net_yi": None,
            "amount_5d_yi": None,
            "amount_20d_yi": None,
            "direction_status": "?", "direction_note": "未实现",
            "velocity_z": None, "velocity_status": "?", "velocity_note": "未实现",
        })

    elif market == "HK":
        # ---------- 南向 bucket ----------
        sb = _fetch_southbound_hist()
        if sb.get("ok"):
            series = _series_from_records(sb["data"], ["当日成交净买额", "净买额", "今日资金净流入"])
            if series is not None:
                metrics = _compute_bucket_metrics(series * 10000 if series.abs().median() < 1e6 else series)
                grid.append(_bucket_to_grid_row("南向", metrics))
            else:
                grid.append({"bucket": "南向", "error": "未找到净买额列"})

        # ---------- 主力 (HK) — limited precision ----------
        grid.append({
            "bucket": "主力(港)",
            "note": "港股主力数据精度低于 A 股，谨慎参考；EM 接口 15 分钟延迟",
            "today_net_yi": None, "amount_5d_yi": None, "amount_20d_yi": None,
            "direction_status": "?", "direction_note": "降级处理",
            "velocity_z": None, "velocity_status": "?", "velocity_note": "降级处理",
        })

        # ---------- 沽空比率 bucket (inverse: high = bearish) ----------
        grid.append({
            "bucket": "沽空率",
            "note": "需补充：港股沽空比率数据；反向指标（升=看空力增）",
            "today_net_yi": None, "amount_5d_yi": None, "amount_20d_yi": None,
            "direction_status": "?", "direction_note": "未实现",
            "velocity_z": None, "velocity_status": "?", "velocity_note": "未实现",
        })

    # Detect FLOW_REGIME_CHANGE
    valid_grid = [r for r in grid if r.get("velocity_z") is not None]
    alert = _detect_flow_regime_change(valid_grid)

    return {
        "ok": True,
        "target": target,
        "target_type": target_type,
        "market": market,
        "as_of": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M"),
        "grid": grid,
        "alert": alert,
        "summary": _generate_summary(grid, alert),
    }


def _generate_summary(grid: list[dict], alert: Optional[dict]) -> str:
    """One-line summary the LLM can paraphrase."""
    n_healthy = sum(1 for r in grid if r.get("direction_status") == "✅")
    n_warning = sum(1 for r in grid if r.get("direction_status") in ("⚠", "❌"))
    n_total = sum(1 for r in grid if r.get("direction_status") and r.get("direction_status") != "?")
    if alert:
        return f"FLOW_REGIME_CHANGE 警报：{alert['direction']}（共振桶：{', '.join(alert['buckets'])}）"
    if n_total == 0:
        return "数据未就绪，无法判断"
    return f"{n_healthy}/{n_total} 桶健康；{n_warning}/{n_total} 桶预警"


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(prog="fund_flow", description="M6 three money trends grid")
    p.add_argument("--target", required=True, help="symbol / industry name / 'all'")
    p.add_argument("--type", choices=["stock", "industry", "concept", "market"], default="stock")
    p.add_argument("--market", choices=["A", "HK"], default="A")
    args = p.parse_args()
    result = compute_three_bucket_grid(args.target, args.type, args.market)
    print(json.dumps(result, ensure_ascii=False, default=str, indent=2))


if __name__ == "__main__":
    main()
