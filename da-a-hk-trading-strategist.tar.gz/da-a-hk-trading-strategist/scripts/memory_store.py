"""
memory_store.py — cross-module persistence for the da-a-hk-trading skill.

Three append-only JSONL stores under `memory/`:

  active_theses.jsonl   — M4 论点登记 (registered hypotheses)
                          {thesis_id, claim, symbols, sectors, stance, strength,
                           trend_break_triggers, time_horizon, registered_at, ...}

  trade_log.jsonl       — M3 复盘归档 (closed trade records)
                          {trade_id, symbol, side, entry/exit prices+dates,
                           holding_days, pnl_pct, decision_quality_score,
                           mistake_tags, lesson_summary, linked_thesis_id, ...}

  forecasts.jsonl       — forecasting-discipline 预测留痕 (Tetlock #10 calibration)
                          {forecast_id, subject, scenario, probability,
                           probability_range, time_horizon_end, time_scale,
                           key_assumptions, trend_break_triggers,
                           bayesian_updates[], resolved, actual_outcome,
                           brier_score, ...}

Why JSONL: append-only, human-greppable, no DB dependency, plays nice with
git for version control and with `jq` for inspection.

Usage from Python:
    from scripts.memory_store import write_thesis, query_active_theses
    write_thesis({"thesis_id": "thesis_20260501_haiyang", ...})
    active = query_active_theses(symbol="00700")

CLI:
    python -m scripts.memory_store thesis-list --active-only
    python -m scripts.memory_store forecast-resolve --id fc_20260501_001 --outcome 1
    python -m scripts.memory_store calibration --since 2026-01-01
"""
from __future__ import annotations

import argparse
import json
import os
from dataclasses import dataclass, asdict
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any, Iterator, Optional


# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------

MEMORY_DIR = Path(os.environ.get("DA_A_HK_MEMORY_DIR", "./memory")).expanduser()
THESES_FILE = MEMORY_DIR / "active_theses.jsonl"
TRADES_FILE = MEMORY_DIR / "trade_log.jsonl"
FORECASTS_FILE = MEMORY_DIR / "forecasts.jsonl"


def _ensure_dir():
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)


# --------------------------------------------------------------------------
# Generic JSONL helpers
# --------------------------------------------------------------------------

def _append(path: Path, record: dict) -> None:
    _ensure_dir()
    record = dict(record)
    record.setdefault("_written_at", datetime.now(timezone.utc).isoformat())
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")


def _iter(path: Path) -> Iterator[dict]:
    if not path.exists():
        return
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                continue  # skip malformed lines


def _rewrite(path: Path, records: list[dict]) -> None:
    """Atomically replace the JSONL file (used for in-place updates)."""
    _ensure_dir()
    tmp = path.with_suffix(".jsonl.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False, default=str) + "\n")
    tmp.replace(path)


# --------------------------------------------------------------------------
# Theses (M4)
# --------------------------------------------------------------------------

def write_thesis(thesis: dict) -> str:
    """Append a thesis record. Required keys:
       thesis_id, claim, stance, strength, trend_break_triggers, time_horizon
    Returns the thesis_id."""
    required = {"thesis_id", "claim"}
    missing = required - set(thesis.keys())
    if missing:
        raise ValueError(f"thesis missing required keys: {missing}")
    thesis.setdefault("registered_at", datetime.now(timezone.utc).isoformat())
    thesis.setdefault("status", "active")
    _append(THESES_FILE, thesis)
    return thesis["thesis_id"]


def query_active_theses(symbol: Optional[str] = None,
                         sector: Optional[str] = None,
                         active_only: bool = True) -> list[dict]:
    """Return matching theses, latest version per thesis_id."""
    by_id: dict[str, dict] = {}
    for r in _iter(THESES_FILE):
        by_id[r.get("thesis_id")] = r  # later writes win
    out = []
    for r in by_id.values():
        if active_only and r.get("status") != "active":
            continue
        if symbol:
            symbols = r.get("symbols") or []
            if symbol not in symbols:
                continue
        if sector:
            sectors = r.get("sectors") or []
            if sector not in sectors:
                continue
        out.append(r)
    return out


def update_thesis(thesis_id: str, **updates) -> bool:
    """In-place edit a thesis (rewrites the file). Returns True if found."""
    records = list(_iter(THESES_FILE))
    found = False
    for r in records:
        if r.get("thesis_id") == thesis_id:
            r.update(updates)
            r["_updated_at"] = datetime.now(timezone.utc).isoformat()
            found = True
    if found:
        _rewrite(THESES_FILE, records)
    return found


def close_thesis(thesis_id: str, outcome: str, lesson: Optional[str] = None) -> bool:
    """Mark thesis closed. outcome: 'confirmed' | 'invalidated' | 'expired' | 'partial'."""
    return update_thesis(thesis_id, status="closed", outcome=outcome,
                         closed_at=datetime.now(timezone.utc).isoformat(),
                         lesson=lesson)


# --------------------------------------------------------------------------
# Trades (M3)
# --------------------------------------------------------------------------

def write_trade(trade: dict) -> str:
    """Append a closed-trade record. Required keys:
       trade_id, symbol, side, entry_date, entry_price, exit_date, exit_price"""
    required = {"trade_id", "symbol", "entry_date", "entry_price", "exit_date", "exit_price"}
    missing = required - set(trade.keys())
    if missing:
        raise ValueError(f"trade missing required keys: {missing}")
    # Auto-compute pnl_pct if missing
    if "pnl_pct" not in trade and trade.get("entry_price"):
        trade["pnl_pct"] = (trade["exit_price"] - trade["entry_price"]) / trade["entry_price"]
    _append(TRADES_FILE, trade)
    return trade["trade_id"]


def query_trades(symbol: Optional[str] = None,
                 mistake_tag: Optional[str] = None,
                 since: Optional[str] = None) -> list[dict]:
    """Return matching trades, sorted by entry_date desc."""
    out = []
    for r in _iter(TRADES_FILE):
        if symbol and r.get("symbol") != symbol:
            continue
        if mistake_tag and mistake_tag not in (r.get("mistake_tags") or []):
            continue
        if since and r.get("entry_date", "") < since:
            continue
        out.append(r)
    out.sort(key=lambda r: r.get("entry_date", ""), reverse=True)
    return out


def count_mistake_tags(since: Optional[str] = None) -> dict[str, int]:
    """Count occurrences of each mistake tag. Used by M3 to detect 'repeated mistake'."""
    counts: dict[str, int] = {}
    for r in query_trades(since=since):
        for tag in r.get("mistake_tags") or []:
            counts[tag] = counts.get(tag, 0) + 1
    return dict(sorted(counts.items(), key=lambda kv: kv[1], reverse=True))


# --------------------------------------------------------------------------
# Forecasts (forecasting-discipline.md, Tetlock #10)
# --------------------------------------------------------------------------

def write_forecast(fc: dict) -> str:
    """Append a forecast record. Required keys:
       forecast_id, subject, time_scale, time_horizon_end
       at least one of: probability OR scenario_probabilities"""
    required = {"forecast_id", "subject", "time_scale", "time_horizon_end"}
    missing = required - set(fc.keys())
    if missing:
        raise ValueError(f"forecast missing required keys: {missing}")
    if "probability" not in fc and "scenario_probabilities" not in fc:
        raise ValueError("forecast must have probability or scenario_probabilities")
    fc.setdefault("created_at", datetime.now(timezone.utc).isoformat())
    fc.setdefault("resolved", False)
    fc.setdefault("bayesian_updates", [])
    _append(FORECASTS_FILE, fc)
    return fc["forecast_id"]


def update_forecast_probability(forecast_id: str, new_prob: float,
                                 reason: str, signal: str) -> bool:
    """Bayesian update — record a probability change with audit trail."""
    records = list(_iter(FORECASTS_FILE))
    found = False
    for r in records:
        if r.get("forecast_id") == forecast_id:
            old_prob = r.get("probability", None)
            update = {
                "date": datetime.now(timezone.utc).isoformat(),
                "old_prob": old_prob,
                "new_prob": new_prob,
                "delta_pp": (new_prob - old_prob) * 100 if old_prob is not None else None,
                "signal": signal,
                "reason": reason,
            }
            r.setdefault("bayesian_updates", []).append(update)
            r["probability"] = new_prob
            found = True
    if found:
        _rewrite(FORECASTS_FILE, records)
    return found


def resolve_forecast(forecast_id: str, actual_outcome: float) -> Optional[float]:
    """Mark a forecast resolved with actual binary outcome (0 or 1).
    Returns the computed Brier score, or None if forecast not found."""
    records = list(_iter(FORECASTS_FILE))
    brier = None
    for r in records:
        if r.get("forecast_id") == forecast_id:
            r["resolved"] = True
            r["actual_outcome"] = actual_outcome
            r["resolved_at"] = datetime.now(timezone.utc).isoformat()
            prob = r.get("probability")
            if prob is not None:
                brier = (prob - actual_outcome) ** 2
                r["brier_score"] = brier
    if brier is not None:
        _rewrite(FORECASTS_FILE, records)
    return brier


def query_forecasts(resolved: Optional[bool] = None,
                    time_scale: Optional[str] = None,
                    since: Optional[str] = None) -> list[dict]:
    """Return matching forecast records."""
    out = []
    for r in _iter(FORECASTS_FILE):
        if resolved is not None and r.get("resolved") != resolved:
            continue
        if time_scale and r.get("time_scale") != time_scale:
            continue
        if since and r.get("created_at", "") < since:
            continue
        out.append(r)
    return out


def calibration_report(since: Optional[str] = None) -> dict:
    """Generate calibration report for resolved forecasts.

    Buckets by predicted probability (0-20%, 20-40%, ..., 80-100%) and reports:
      - Number of predictions in bucket
      - Actual frequency (mean of actual_outcome)
      - Average predicted probability in bucket
      - Calibration delta (actual - predicted, want close to 0)
      - Average Brier score in bucket

    A well-calibrated forecaster has actual frequency ≈ midpoint of bucket.
    """
    resolved = [f for f in query_forecasts(resolved=True, since=since) if f.get("probability") is not None]
    if not resolved:
        return {"n_resolved": 0, "message": "No resolved forecasts in range"}

    buckets = [(0.0, 0.2), (0.2, 0.4), (0.4, 0.6), (0.6, 0.8), (0.8, 1.0)]
    report = {"n_resolved": len(resolved), "since": since, "buckets": []}

    for lo, hi in buckets:
        in_bucket = [f for f in resolved if lo <= f["probability"] < hi]
        if not in_bucket:
            report["buckets"].append({
                "range": f"{int(lo*100)}-{int(hi*100)}%",
                "n": 0,
                "actual_frequency": None,
                "avg_predicted": None,
                "calibration_delta": None,
                "avg_brier": None,
            })
            continue
        avg_pred = sum(f["probability"] for f in in_bucket) / len(in_bucket)
        actual_freq = sum(f["actual_outcome"] for f in in_bucket) / len(in_bucket)
        avg_brier = sum(f.get("brier_score", 0) for f in in_bucket) / len(in_bucket)
        report["buckets"].append({
            "range": f"{int(lo*100)}-{int(hi*100)}%",
            "n": len(in_bucket),
            "actual_frequency": round(actual_freq, 3),
            "avg_predicted": round(avg_pred, 3),
            "calibration_delta": round(actual_freq - avg_pred, 3),
            "avg_brier": round(avg_brier, 4),
        })

    overall_brier = sum(f.get("brier_score", 0) for f in resolved) / len(resolved)
    report["overall_brier"] = round(overall_brier, 4)
    report["overall_brier_grade"] = (
        "excellent (<0.10)" if overall_brier < 0.10 else
        "good (0.10-0.18)" if overall_brier < 0.18 else
        "acceptable (0.18-0.25)" if overall_brier < 0.25 else
        "poor (>0.25, recalibrate)"
    )

    # Bias diagnosis
    biases = []
    for b in report["buckets"]:
        if b["n"] >= 3 and b["calibration_delta"] is not None:
            if b["calibration_delta"] > 0.10:
                biases.append(f"Underconfident in {b['range']} bucket (actual {int(b['actual_frequency']*100)}%, predicted {int(b['avg_predicted']*100)}%)")
            elif b["calibration_delta"] < -0.10:
                biases.append(f"Overconfident in {b['range']} bucket (actual {int(b['actual_frequency']*100)}%, predicted {int(b['avg_predicted']*100)}%)")
    report["bias_diagnosis"] = biases

    return report


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def _emit(obj: Any) -> None:
    print(json.dumps(obj, ensure_ascii=False, default=str, indent=2))


def main():
    p = argparse.ArgumentParser(prog="memory_store", description="Cross-module memory store for da-a-hk-trading")
    sub = p.add_subparsers(dest="cmd", required=True)

    # theses
    p_tl = sub.add_parser("thesis-list", help="List theses")
    p_tl.add_argument("--symbol", default=None)
    p_tl.add_argument("--sector", default=None)
    p_tl.add_argument("--active-only", action="store_true", default=True)
    p_tl.add_argument("--all", dest="active_only", action="store_false")

    p_tw = sub.add_parser("thesis-write", help="Write a thesis (JSON via --json)")
    p_tw.add_argument("--json", required=True)

    p_tc = sub.add_parser("thesis-close", help="Close a thesis")
    p_tc.add_argument("--id", required=True)
    p_tc.add_argument("--outcome", required=True, choices=["confirmed", "invalidated", "expired", "partial"])
    p_tc.add_argument("--lesson", default=None)

    # trades
    p_trl = sub.add_parser("trade-list", help="List trades")
    p_trl.add_argument("--symbol", default=None)
    p_trl.add_argument("--tag", default=None)
    p_trl.add_argument("--since", default=None)

    p_trm = sub.add_parser("trade-mistakes", help="Count mistake tags")
    p_trm.add_argument("--since", default=None)

    p_trw = sub.add_parser("trade-write", help="Write a trade (JSON via --json)")
    p_trw.add_argument("--json", required=True)

    # forecasts
    p_fl = sub.add_parser("forecast-list", help="List forecasts")
    p_fl.add_argument("--resolved", choices=["true", "false"], default=None)
    p_fl.add_argument("--scale", default=None)

    p_fw = sub.add_parser("forecast-write", help="Write a forecast (JSON via --json)")
    p_fw.add_argument("--json", required=True)

    p_fr = sub.add_parser("forecast-resolve", help="Resolve a forecast with actual outcome")
    p_fr.add_argument("--id", required=True)
    p_fr.add_argument("--outcome", type=float, required=True, help="0 or 1 (binary outcome)")

    p_fu = sub.add_parser("forecast-update", help="Bayesian update a forecast probability")
    p_fu.add_argument("--id", required=True)
    p_fu.add_argument("--new-prob", type=float, required=True)
    p_fu.add_argument("--signal", required=True)
    p_fu.add_argument("--reason", required=True)

    p_cal = sub.add_parser("calibration", help="Calibration report")
    p_cal.add_argument("--since", default=None)

    args = p.parse_args()

    if args.cmd == "thesis-list":
        _emit(query_active_theses(symbol=args.symbol, sector=args.sector, active_only=args.active_only))
    elif args.cmd == "thesis-write":
        _emit({"thesis_id": write_thesis(json.loads(args.json))})
    elif args.cmd == "thesis-close":
        _emit({"closed": close_thesis(args.id, args.outcome, args.lesson)})
    elif args.cmd == "trade-list":
        _emit(query_trades(symbol=args.symbol, mistake_tag=args.tag, since=args.since))
    elif args.cmd == "trade-mistakes":
        _emit(count_mistake_tags(since=args.since))
    elif args.cmd == "trade-write":
        _emit({"trade_id": write_trade(json.loads(args.json))})
    elif args.cmd == "forecast-list":
        resolved = None if args.resolved is None else args.resolved == "true"
        _emit(query_forecasts(resolved=resolved, time_scale=args.scale))
    elif args.cmd == "forecast-write":
        _emit({"forecast_id": write_forecast(json.loads(args.json))})
    elif args.cmd == "forecast-resolve":
        _emit({"brier_score": resolve_forecast(args.id, args.outcome)})
    elif args.cmd == "forecast-update":
        _emit({"updated": update_forecast_probability(args.id, args.new_prob, args.reason, args.signal)})
    elif args.cmd == "calibration":
        _emit(calibration_report(since=args.since))


if __name__ == "__main__":
    main()
