"""
policy_search.py — M5 政策检索 (Policy Search & Categorization).

Search and categorize Chinese policy / regulatory news from public sources:

    - news_cctv             — 新闻联播 daily transcripts (政策信号源头)
    - stock_info_global_cls — 财联社电报 (near-real-time)
    - news_economic_baidu   — 百度宏观日历

Categorize each hit into 5 buckets per forecasting-discipline.md:
    货币 (monetary)  /  财政 (fiscal)  /  产业 (industrial)
    监管 (regulatory) /  地缘 (geopolitical)

Extract key time markers ("XX 月 YY 日前 ZZ 万亿要下达"), policy issuers, and
keyword-matched receivers (受益板块).

Usage:
    from scripts.policy_search import search_policy
    result = search_policy(keyword="储能", date_range=("2026-04-01", "2026-05-01"))

CLI:
    python -m scripts.policy_search --keywords 储能,新型电力,海洋强国 --days 30
    python -m scripts.policy_search --keywords AI算力 --source cctv,cls --days 14
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Optional


# --------------------------------------------------------------------------
# Policy taxonomy keyword maps
# --------------------------------------------------------------------------

CATEGORY_KEYWORDS = {
    "货币": [
        "央行", "人民银行", "MLF", "OMO", "逆回购", "公开市场", "LPR",
        "存款准备金", "RRR", "降准", "降息", "再贷款", "再贴现",
        "流动性", "利率走廊", "存款利率",
    ],
    "财政": [
        "财政部", "专项债", "国债", "特别国债", "中央预算", "赤字率",
        "减税降费", "财政支出", "转移支付", "政府引导基金", "PPP",
        "中央经济工作会议", "财政政策",
    ],
    "产业": [
        "发改委", "工信部", "国家能源局", "科技部", "国资委",
        "十四五", "十五五", "规划", "行动方案", "实施意见", "意见",
        "新型能源体系", "新能源", "新型电力", "储能", "光伏", "风电",
        "半导体", "集成电路", "芯片", "国产替代", "AI", "人工智能",
        "数字经济", "数据中心", "5G", "6G",
        "海洋强国", "海洋经济", "海工装备", "深远海",
        "城市更新", "国家水网", "新基建",
        "生物医药", "创新药", "高端制造", "智能制造",
    ],
    "监管": [
        "证监会", "银保监会", "国家金融监督管理总局", "网信办",
        "反垄断", "市场监管", "行业整顿", "合规", "审查", "禁令",
        "罚款", "处罚", "退市", "ST",
        "教育部", "双减", "互联网平台",
    ],
    "地缘": [
        "出口管制", "实体清单", "制裁", "贸易协议", "关税",
        "中美", "美方", "欧盟", "日本", "韩国", "台海",
        "南海", "霍尔木兹", "俄乌", "中东", "外交部",
        "WTO", "RCEP", "一带一路",
    ],
}

# Sector impact lookup — maps category + keyword to positively/negatively affected sectors
SECTOR_IMPACT_MAP = {
    "新型电力": {"+": ["储能", "光伏", "风电", "电网设备"], "-": []},
    "新型储能": {"+": ["储能逆变器", "储能电芯", "储能集成商"], "-": []},
    "海洋强国": {"+": ["海工装备", "海上风电", "远洋船舶", "港口"], "-": []},
    "AI 配套基建": {"+": ["AI 算力", "数据中心", "光模块", "服务器"], "-": []},
    "半导体国产替代": {"+": ["半导体设备", "晶圆制造", "材料"], "-": []},
    "降准": {"+": ["地产", "银行", "高估值成长"], "-": ["保险（短期）"]},
    "降息": {"+": ["地产", "高估值成长", "REITs"], "-": ["银行"]},
    "专项债": {"+": ["基建", "城投", "工程机械", "建材"], "-": []},
    "反垄断": {"+": [], "-": ["互联网平台", "大型科技"]},
    "出口管制": {"+": ["国产替代"], "-": ["出口受管制板块"]},
}


# --------------------------------------------------------------------------
# Time-marker extraction
# --------------------------------------------------------------------------

# Patterns like "6 月底前", "2026 年底前", "7 月 15 日前"
TIME_MARKER_RE = re.compile(
    r"(\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日\s*前|"
    r"\d{1,2}\s*月\s*\d{1,2}\s*日\s*前|"
    r"\d{4}\s*年(?:\s*\d{1,2}\s*月)?\s*底前|"
    r"\d{1,2}\s*月\s*底前|"
    r"\d{4}\s*年\s*\d{1,2}\s*月)"
)

# Patterns for amounts: "1.755 万亿", "3000 亿元", "500 亿"
AMOUNT_RE = re.compile(
    r"(\d+(?:\.\d+)?\s*万亿|"
    r"\d+(?:\.\d+)?\s*亿元?|"
    r"\d+(?:\.\d+)?\s*千亿)"
)


# --------------------------------------------------------------------------
# Categorization & extraction
# --------------------------------------------------------------------------

def _categorize(text: str) -> dict:
    """Return categories whose keywords appear in text, with hit counts."""
    hits = {}
    for cat, kws in CATEGORY_KEYWORDS.items():
        cat_hits = [kw for kw in kws if kw in text]
        if cat_hits:
            hits[cat] = cat_hits
    return hits


def _extract_time_markers(text: str) -> list[str]:
    return list(set(TIME_MARKER_RE.findall(text)))


def _extract_amounts(text: str) -> list[str]:
    return list(set(AMOUNT_RE.findall(text)))


def _infer_sector_impacts(hit_keywords: list[str]) -> dict:
    """Map matched keywords to sector impact directions."""
    impacts = {"benefits": set(), "hurts": set(), "matched_terms": []}
    for kw in hit_keywords:
        if kw in SECTOR_IMPACT_MAP:
            impacts["benefits"].update(SECTOR_IMPACT_MAP[kw]["+"])
            impacts["hurts"].update(SECTOR_IMPACT_MAP[kw]["-"])
            impacts["matched_terms"].append(kw)
    return {
        "benefits": sorted(impacts["benefits"]),
        "hurts": sorted(impacts["hurts"]),
        "matched_terms": impacts["matched_terms"],
    }


# --------------------------------------------------------------------------
# Source fetchers
# --------------------------------------------------------------------------

def _search_cctv(keywords: list[str], days: int) -> list[dict]:
    """Search CCTV 新闻联播 transcripts for keyword hits in the last N days."""
    from scripts.akshare_helpers import fetch_news_cctv
    hits = []
    for d in range(days):
        target_date = (date.today() - timedelta(days=d)).strftime("%Y%m%d")
        result = fetch_news_cctv(target_date)
        if not result.get("ok"):
            continue
        for record in result.get("data", []):
            text = " ".join(str(v) for v in record.values() if v)
            matched_kws = [kw for kw in keywords if kw in text]
            if matched_kws:
                hits.append({
                    "source": "新闻联播",
                    "date": target_date,
                    "title": record.get("标题") or record.get("title", "")[:80],
                    "content_snippet": text[:300],
                    "matched_keywords": matched_kws,
                })
    return hits


def _search_cls(keywords: list[str]) -> list[dict]:
    """Search 财联社电报 (recent ~12 hours)."""
    from scripts.akshare_helpers import fetch_news_cls
    result = fetch_news_cls()
    if not result.get("ok"):
        return []
    hits = []
    for record in result.get("data", []):
        text = " ".join(str(v) for v in record.values() if v)
        matched_kws = [kw for kw in keywords if kw in text]
        if matched_kws:
            hits.append({
                "source": "财联社电报",
                "date": record.get("发布时间") or record.get("date") or "",
                "title": record.get("标题") or record.get("内容", "")[:80],
                "content_snippet": text[:300],
                "matched_keywords": matched_kws,
            })
    return hits


# --------------------------------------------------------------------------
# Top-level
# --------------------------------------------------------------------------

def search_policy(keywords: list[str], days: int = 30,
                   sources: Optional[list[str]] = None) -> dict:
    """Main entry: search policy news.

    sources: list of "cctv" / "cls" — defaults to both.
    """
    sources = sources or ["cctv", "cls"]
    all_hits = []
    if "cctv" in sources:
        all_hits.extend(_search_cctv(keywords, days))
    if "cls" in sources:
        all_hits.extend(_search_cls(keywords))

    # Enrich each hit with categorization + time markers + amount + sector impacts
    for h in all_hits:
        text = h["content_snippet"]
        h["categories"] = _categorize(text)
        h["time_markers"] = _extract_time_markers(text)
        h["amounts"] = _extract_amounts(text)
        h["sector_impacts"] = _infer_sector_impacts(h["matched_keywords"])

    # Aggregate
    category_counts = {cat: 0 for cat in CATEGORY_KEYWORDS}
    for h in all_hits:
        for cat in h["categories"]:
            category_counts[cat] += 1

    all_benefits = set()
    all_hurts = set()
    all_time_markers = set()
    for h in all_hits:
        all_benefits.update(h["sector_impacts"]["benefits"])
        all_hurts.update(h["sector_impacts"]["hurts"])
        all_time_markers.update(h["time_markers"])

    return {
        "ok": True,
        "keywords": keywords,
        "days": days,
        "sources": sources,
        "n_hits": len(all_hits),
        "category_distribution": {k: v for k, v in category_counts.items() if v > 0},
        "all_benefiting_sectors": sorted(all_benefits),
        "all_hurting_sectors": sorted(all_hurts),
        "all_time_markers": sorted(all_time_markers),
        "hits": sorted(all_hits, key=lambda h: h.get("date", ""), reverse=True),
    }


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(prog="policy_search", description="M5 policy retrieval and categorization")
    p.add_argument("--keywords", required=True, help="comma-separated keywords")
    p.add_argument("--days", type=int, default=30, help="search window in days (CCTV)")
    p.add_argument("--source", default="cctv,cls", help="comma-separated: cctv,cls")
    p.add_argument("--max-hits", type=int, default=50)
    args = p.parse_args()
    keywords = [k.strip() for k in args.keywords.split(",") if k.strip()]
    sources = [s.strip() for s in args.source.split(",") if s.strip()]
    result = search_policy(keywords, args.days, sources)
    # Cap hits in CLI for readability
    if "hits" in result and len(result["hits"]) > args.max_hits:
        result["hits"] = result["hits"][:args.max_hits]
        result["truncated"] = True
    print(json.dumps(result, ensure_ascii=False, default=str, indent=2))


if __name__ == "__main__":
    main()
