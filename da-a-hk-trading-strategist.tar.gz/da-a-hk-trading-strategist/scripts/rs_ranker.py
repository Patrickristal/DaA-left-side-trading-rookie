"""
rs_ranker.py — 板块内龙头排序 (Sector Leader Ranking).

Solves Patrick's "板块对了选股次了" problem with multi-source cross-validation.
For each candidate stock in a sector, rank by:

    1. 板块内 5/20 日涨幅排名 (RS rank within sector)
    2. RS_vs_sector_20d (relative strength vs sector index)
    3. 主力净流入 (last 5 trading days)
    4. 北向持股变化 (last 5 trading days)
    5. 龙虎榜入榜 + 知名游资席位 (last 5 trading days)
    6. 同花顺概念排名 (when available)

Output: ranked candidates with classification:
    强龙头 (strong leader)  — RS top 3 + 同花顺 top 5 + 知名游资 + 雪球关注上升
    二线   (second-tier)    — 2 of the above
    跟风   (laggard)        — 0-1 of the above (warn)

Usage:
    from scripts.rs_ranker import rank_sector
    result = rank_sector("储能设备", market="A", top_n=10)

CLI:
    python -m scripts.rs_ranker --sector "储能设备" --market A --top-n 10
    python -m scripts.rs_ranker --concept "AI 算力" --market A
"""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, asdict
from typing import Optional

try:
    import numpy as np
    import pandas as pd
except ImportError:
    print(json.dumps({"ok": False, "error": "numpy and pandas required"}))
    sys.exit(1)


# --------------------------------------------------------------------------
# Known 知名游资 / 著名机构 seat names (for 龙虎榜 detection)
# --------------------------------------------------------------------------

# Patrick: this list is incomplete by design. Expand as you observe new desks.
FAMOUS_HOTMONEY_SEATS = {
    "东方财富证券拉萨团结路第二证券营业部": "拉萨天团",
    "中国银河证券绍兴证券营业部": "章盟主关联",
    "华鑫证券上海分公司": "古北一姐",
    "国泰君安证券南京太平南路证券营业部": "南京太平南路",
    "财通证券杭州金城路证券营业部": "金城路",
    "国信证券深圳泰然九路证券营业部": "泰然九路",
    "招商证券天津友谊路证券营业部": "天津友谊路",
    "中信证券上海溧阳路证券营业部": "溧阳路",
    "海通证券绍兴解放北路证券营业部": "解放北路",
    "光大证券宁波解放南路证券营业部": "宁波解放南路",
}

FAMOUS_INSTITUTIONAL_SEATS = {
    "中金财富": "中金机构",
    "中信证券": "中信机构",
    "中信建投": "中信建投机构",
    "招商证券": "招商机构",
    "国泰君安": "国君机构",
    "海通证券": "海通机构",
}


# --------------------------------------------------------------------------
# Helpers: pull sector constituents and per-stock metrics
# --------------------------------------------------------------------------

def _get_constituents(target: str, target_type: str = "industry", market: str = "A") -> list[dict]:
    """Fetch constituents of an industry / concept board."""
    from scripts.akshare_helpers import (
        fetch_industry_constituents, fetch_concept_constituents
    )
    if target_type == "industry":
        result = fetch_industry_constituents(target)
    elif target_type == "concept":
        result = fetch_concept_constituents(target)
    else:
        return []
    if not result.get("ok"):
        return []
    return result["data"]


def _get_individual_metrics(symbol: str, market: str = "A") -> dict:
    """Pull per-stock 5-day return, 20-day return, 主力净流入, 北向持股."""
    from scripts.akshare_helpers import fetch_ohlcv, _safe_call, normalize_symbol
    sym = normalize_symbol(symbol, market)

    # Returns
    ohlcv = fetch_ohlcv(symbol, market, period="daily", days=30)
    ret_5d = ret_20d = None
    if ohlcv.get("ok") and ohlcv["data"]:
        df = pd.DataFrame(ohlcv["data"])
        if "收盘" in df.columns:
            df = df.rename(columns={"收盘": "close", "日期": "date"})
        if "close" in df.columns and len(df) >= 21:
            close = pd.to_numeric(df["close"], errors="coerce").dropna()
            if len(close) >= 21:
                ret_5d = (close.iloc[-1] / close.iloc[-6] - 1) * 100
                ret_20d = (close.iloc[-1] / close.iloc[-21] - 1) * 100

    # 主力 净流入 (5日累计)
    main_flow_5d = None
    if market == "A":
        ex = sym.exchange.lower() if sym.exchange in ("SH", "SZ") else "sh"
        flow = _safe_call("stock_individual_fund_flow", stock=sym.em_format, market=ex)
        if flow.get("ok") and flow["data"]:
            df_f = pd.DataFrame(flow["data"])
            col = next((c for c in df_f.columns if "主力净流入" in c and "净额" in c), None)
            if col:
                main_flow_5d = pd.to_numeric(df_f[col].tail(5), errors="coerce").sum() / 1e8

    # 北向持股变化 (5日累计)
    nb_change_5d = None
    if market == "A":
        nb = _safe_call("stock_hsgt_individual_em", stock=sym.em_format)
        if nb.get("ok") and nb["data"]:
            df_n = pd.DataFrame(nb["data"])
            col = next((c for c in df_n.columns if "持股" in c and "变化" in c), None)
            if col:
                nb_change_5d = pd.to_numeric(df_n[col].tail(5), errors="coerce").sum()

    return {
        "symbol": sym.em_format,
        "ret_5d_pct": round(ret_5d, 2) if ret_5d is not None else None,
        "ret_20d_pct": round(ret_20d, 2) if ret_20d is not None else None,
        "main_flow_5d_yi": round(main_flow_5d, 2) if main_flow_5d is not None else None,
        "northbound_change_5d": nb_change_5d,
    }


def _get_lhb_appearances(symbol: str, days: int = 5) -> dict:
    """Check if symbol appeared on 龙虎榜 in the last N days, and which seats bought."""
    from scripts.akshare_helpers import _safe_call, normalize_symbol
    from datetime import date, timedelta
    sym = normalize_symbol(symbol, "A")
    end = date.today().strftime("%Y%m%d")
    start = (date.today() - timedelta(days=days * 2)).strftime("%Y%m%d")
    result = _safe_call("stock_lhb_detail_em", start_date=start, end_date=end)
    if not result.get("ok"):
        return {"appearances": 0, "famous_hotmoney": [], "famous_institutional": []}
    df = pd.DataFrame(result["data"])
    if df.empty:
        return {"appearances": 0, "famous_hotmoney": [], "famous_institutional": []}
    code_col = next((c for c in df.columns if "代码" in c), None)
    if code_col is None:
        return {"appearances": 0, "famous_hotmoney": [], "famous_institutional": []}
    matches = df[df[code_col].astype(str).str.contains(sym.em_format)]
    if matches.empty:
        return {"appearances": 0, "famous_hotmoney": [], "famous_institutional": []}
    seat_col = next((c for c in matches.columns if "营业部" in c or "席位" in c), None)
    famous_hot = []
    famous_inst = []
    if seat_col:
        for seat in matches[seat_col].astype(str).unique():
            for known, label in FAMOUS_HOTMONEY_SEATS.items():
                if known in seat:
                    famous_hot.append(label)
            for known, label in FAMOUS_INSTITUTIONAL_SEATS.items():
                if known in seat:
                    famous_inst.append(label)
    return {
        "appearances": len(matches),
        "famous_hotmoney": list(set(famous_hot)),
        "famous_institutional": list(set(famous_inst)),
    }


# --------------------------------------------------------------------------
# Scoring
# --------------------------------------------------------------------------

def _classify(scores: dict) -> str:
    """Decide 强龙头 / 二线 / 跟风 based on composite signals."""
    points = 0
    if scores.get("rank_in_sector_5d") is not None and scores["rank_in_sector_5d"] <= 3:
        points += 1
    if scores.get("ret_20d_outperformance_pp") is not None and scores["ret_20d_outperformance_pp"] > 0:
        points += 1
    if scores.get("main_flow_5d_yi") is not None and scores["main_flow_5d_yi"] > 0.5:
        points += 1
    if scores.get("famous_hotmoney"):
        points += 1
    if scores.get("famous_institutional"):
        points += 1
    if scores.get("northbound_change_5d") is not None and scores["northbound_change_5d"] > 0:
        points += 1

    if points >= 5:
        return "强龙头"
    if points >= 3:
        return "二线"
    return "跟风"


def rank_sector(target: str, target_type: str = "industry", market: str = "A",
                top_n: int = 10, fast: bool = False) -> dict:
    """Main entry: rank candidates within a sector.

    `fast=True` skips slow per-stock data calls (LHB / 北向 individual) and uses
    only sector-level returns. Useful for quick scans.
    """
    constituents = _get_constituents(target, target_type, market)
    if not constituents:
        return {"ok": False, "error": f"未找到 {target} 的成分股 (target_type={target_type})"}

    df = pd.DataFrame(constituents)
    # AKShare typically returns columns 代码 / 名称 / 涨跌幅 / 换手率 etc.
    code_col = next((c for c in df.columns if "代码" in c), None)
    name_col = next((c for c in df.columns if "名称" in c), None)
    pct_col = next((c for c in df.columns if "涨跌幅" in c), None)
    if not code_col:
        return {"ok": False, "error": f"成分股数据缺代码列: {list(df.columns)}"}

    # Pre-rank by today's 涨跌幅 to speed up — only deep-dive top 30
    if pct_col:
        df["_pct"] = pd.to_numeric(df[pct_col], errors="coerce")
        df = df.sort_values("_pct", ascending=False).reset_index(drop=True)
    initial_top = df.head(min(30, len(df))).copy()

    # Compute per-stock metrics
    enriched = []
    for i, row in initial_top.iterrows():
        sym = str(row[code_col])
        name = str(row[name_col]) if name_col else sym

        if fast:
            metrics = {"symbol": sym, "ret_5d_pct": None, "ret_20d_pct": None,
                       "main_flow_5d_yi": None, "northbound_change_5d": None}
            lhb = {"appearances": 0, "famous_hotmoney": [], "famous_institutional": []}
        else:
            try:
                metrics = _get_individual_metrics(sym, market)
                lhb = _get_lhb_appearances(sym, days=5)
            except Exception as e:
                metrics = {"symbol": sym, "ret_5d_pct": None}
                lhb = {"appearances": 0, "famous_hotmoney": [], "famous_institutional": []}

        enriched.append({
            "code": sym,
            "name": name,
            "today_pct_change": float(row.get("_pct", 0) or 0),
            **metrics,
            "lhb_appearances_5d": lhb["appearances"],
            "famous_hotmoney": lhb["famous_hotmoney"],
            "famous_institutional": lhb["famous_institutional"],
        })

    # Compute sector benchmark for outperformance
    valid_rets = [e["ret_20d_pct"] for e in enriched if e.get("ret_20d_pct") is not None]
    sector_avg_20d = np.mean(valid_rets) if valid_rets else None

    # Rank within enriched set by 5d return
    sorted_by_5d = sorted(
        [e for e in enriched if e.get("ret_5d_pct") is not None],
        key=lambda e: e["ret_5d_pct"], reverse=True,
    )
    rank_map = {e["code"]: i + 1 for i, e in enumerate(sorted_by_5d)}

    # Final scoring
    final = []
    for e in enriched:
        outperf = None
        if e.get("ret_20d_pct") is not None and sector_avg_20d is not None:
            outperf = round(e["ret_20d_pct"] - sector_avg_20d, 2)
        e["rank_in_sector_5d"] = rank_map.get(e["code"])
        e["ret_20d_outperformance_pp"] = outperf
        e["classification"] = _classify(e)
        final.append(e)

    # Sort by rank_in_sector_5d, then by outperformance
    final.sort(key=lambda e: (e.get("rank_in_sector_5d") or 999,
                              -(e.get("ret_20d_outperformance_pp") or -999)))

    return {
        "ok": True,
        "target": target,
        "target_type": target_type,
        "market": market,
        "n_constituents": len(constituents),
        "n_analyzed": len(enriched),
        "sector_avg_20d_pct": round(sector_avg_20d, 2) if sector_avg_20d is not None else None,
        "ranking": final[:top_n],
        "summary": _summarize(final[:top_n]),
    }


def _summarize(top: list[dict]) -> dict:
    leaders = [e for e in top if e["classification"] == "强龙头"]
    second = [e for e in top if e["classification"] == "二线"]
    laggards = [e for e in top if e["classification"] == "跟风"]
    return {
        "强龙头": [f"{e['name']} ({e['code']})" for e in leaders],
        "二线": [f"{e['name']} ({e['code']})" for e in second],
        "跟风嫌疑": [f"{e['name']} ({e['code']})" for e in laggards],
        "建议": (
            f"识别出 {len(leaders)} 只强龙头候选 — 重点关注；"
            if leaders else
            "未识别出强龙头 — 板块可能尚未启动，或龙头不在 top 30 涨幅内。"
        ),
    }


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(prog="rs_ranker", description="M1+M2 sector leader ranking")
    p.add_argument("--sector", default=None, help="industry name")
    p.add_argument("--concept", default=None, help="concept name (alternative to --sector)")
    p.add_argument("--market", choices=["A", "HK"], default="A")
    p.add_argument("--top-n", type=int, default=10)
    p.add_argument("--fast", action="store_true", help="skip per-stock LHB / 北向 calls")
    args = p.parse_args()
    target = args.sector or args.concept
    if not target:
        p.error("must provide --sector or --concept")
    target_type = "industry" if args.sector else "concept"
    result = rank_sector(target, target_type, args.market, args.top_n, args.fast)
    print(json.dumps(result, ensure_ascii=False, default=str, indent=2))


if __name__ == "__main__":
    main()
