"""
ta_factors.py — M2 的命名因子注册表 (Named Factor Registry).

Computes ~26 named technical factors from OHLCV data, returning a clean dict
that the LLM can consume and present back to Patrick using consistent factor
names. The registry is the cure for "limited TA vocabulary" — by always
showing the same names with values + status symbols, Patrick builds vocabulary
through repetition.

Output schema per factor:
    {
        "value": <number | string | None>,
        "status": "✅" | "⚠" | "❌" | "↗" | "↘" | "→",
        "note": <one-line interpretation>,
    }

Categories (5 groups + patterns):
    A. Stage (Weinstein)         — weinstein_stage, MA20_slope_5d, ...
    B. Position                  — price_vs_MA20_pct, price_to_52w_high_pct, ...
    C. Volume-Price              — vol_ratio_5_20, vol_price_consistency_5d, ...
    D. Momentum                  — RSI14_daily, MACD_hist_daily, ...
    E. Volatility & Strength     — BOLL_position_20d, ATR14_pct, RS_vs_sector_*, ...
    F. Patterns                  — pattern_basic, pivot_breakout_state

Usage:
    from scripts.ta_factors import compute_factors
    result = compute_factors("600519", market="A", period="daily")

CLI:
    python -m scripts.ta_factors --symbol 600519 --market A
    python -m scripts.ta_factors --symbol 600519 --factors weinstein_stage,RSI14_daily
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from typing import Optional

try:
    import numpy as np
    import pandas as pd
except ImportError:
    print(json.dumps({"ok": False, "error": "numpy and pandas required"}))
    sys.exit(1)


# --------------------------------------------------------------------------
# Indicator math (pure numpy/pandas, no external TA library required)
# --------------------------------------------------------------------------

def _ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False).mean()


def _macd(close: pd.Series) -> tuple[pd.Series, pd.Series, pd.Series]:
    """Returns (macd_line, signal, histogram)."""
    macd = _ema(close, 12) - _ema(close, 26)
    signal = _ema(macd, 9)
    hist = macd - signal
    return macd, signal, hist


def _rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = -delta.where(delta < 0, 0.0)
    avg_gain = gain.rolling(period).mean()
    avg_loss = loss.rolling(period).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))


def _kdj(high: pd.Series, low: pd.Series, close: pd.Series, n: int = 9) -> tuple[pd.Series, pd.Series, pd.Series]:
    low_n = low.rolling(n).min()
    high_n = high.rolling(n).max()
    rsv = (close - low_n) / (high_n - low_n) * 100
    k = rsv.ewm(com=2).mean()
    d = k.ewm(com=2).mean()
    j = 3 * k - 2 * d
    return k, d, j


def _atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
    prev_close = close.shift(1)
    tr = pd.concat([
        (high - low).abs(),
        (high - prev_close).abs(),
        (low - prev_close).abs(),
    ], axis=1).max(axis=1)
    return tr.rolling(period).mean()


def _boll(close: pd.Series, period: int = 20, k: float = 2.0):
    ma = close.rolling(period).mean()
    sd = close.rolling(period).std(ddof=0)
    upper = ma + k * sd
    lower = ma - k * sd
    return ma, upper, lower


# --------------------------------------------------------------------------
# Factor computers — each returns {value, status, note}
# --------------------------------------------------------------------------

def _f_weinstein_stage(df: pd.DataFrame, weekly: pd.DataFrame) -> dict:
    """Stage 1 (底部盘整) / 2 (上升) / 3 (顶部盘整) / 4 (下降).
    Decision based on weekly 30 MA direction + price position."""
    if len(weekly) < 35:
        return {"value": None, "status": "?", "note": "周线样本不足 (<35 周)"}
    close_w = weekly["close"]
    ma30 = close_w.rolling(30).mean()
    last_close = close_w.iloc[-1]
    last_ma = ma30.iloc[-1]
    ma_slope = (ma30.iloc[-1] - ma30.iloc[-5]) / ma30.iloc[-5] if not pd.isna(ma30.iloc[-5]) else 0
    above = last_close > last_ma
    rising = ma_slope > 0.005

    if above and rising:
        return {"value": 2, "status": "✅", "note": "Stage 2 上升趋势 (周线 30MA 上方 + MA 上行)"}
    if not above and not rising:
        return {"value": 4, "status": "❌", "note": "Stage 4 下降趋势 (周线 30MA 下方 + MA 下行)"}
    if above and not rising:
        return {"value": 3, "status": "⚠", "note": "Stage 3 顶部盘整 (周线 30MA 上方但 MA 走平/下行)"}
    return {"value": 1, "status": "→", "note": "Stage 1 底部盘整 (周线 30MA 下方但 MA 走平/上行)"}


def _f_ma_slope(df: pd.DataFrame, ma_period: int, lookback: int) -> dict:
    """Annualized slope of MA over `lookback` days, in percent."""
    close = df["close"]
    ma = close.rolling(ma_period).mean()
    if pd.isna(ma.iloc[-lookback]):
        return {"value": None, "status": "?", "note": "样本不足"}
    pct = (ma.iloc[-1] - ma.iloc[-lookback]) / ma.iloc[-lookback]
    annualized = (1 + pct) ** (252 / lookback) - 1 if pct > -0.99 else -1
    pct_display = round(annualized * 100, 1)
    if annualized > 0.30:
        st = "✅"
    elif annualized > 0:
        st = "→"
    elif annualized > -0.10:
        st = "⚠"
    else:
        st = "❌"
    return {"value": pct_display, "status": st,
            "note": f"MA{ma_period} 最近 {lookback} 日年化斜率 {pct_display}%"}


def _f_ma_alignment(df: pd.DataFrame) -> dict:
    """5/10/20/60 日均线多头排列状态."""
    close = df["close"]
    if len(close) < 60:
        return {"value": None, "status": "?", "note": "样本不足 60 日"}
    m5, m10, m20, m60 = [close.rolling(p).mean().iloc[-1] for p in (5, 10, 20, 60)]
    m5_prev, m10_prev, m20_prev, m60_prev = [close.rolling(p).mean().iloc[-5] for p in (5, 10, 20, 60)]
    rising = (m5 > m5_prev) and (m10 > m10_prev) and (m20 > m20_prev) and (m60 > m60_prev)
    bull = m5 > m10 > m20 > m60
    bear = m5 < m10 < m20 < m60
    if bull and rising:
        v, st, note = "full", "✅", "5>10>20>60 多头排列且全部上行"
    elif bull:
        v, st, note = "partial", "→", "多头排列但部分均线走平"
    elif bear:
        v, st, note = "inverse", "❌", "5<10<20<60 空头排列"
    else:
        v, st, note = "broken", "⚠", "均线交错，趋势不明"
    return {"value": v, "status": st, "note": note}


def _f_price_vs_ma(df: pd.DataFrame, ma_period: int) -> dict:
    close = df["close"]
    ma = close.rolling(ma_period).mean()
    if pd.isna(ma.iloc[-1]):
        return {"value": None, "status": "?", "note": "样本不足"}
    pct = (close.iloc[-1] - ma.iloc[-1]) / ma.iloc[-1]
    val = round(pct * 100, 1)
    if ma_period == 20:
        if 0 <= pct <= 0.10:
            st, note = "✅", "在 MA20 上方且距离健康"
        elif pct < -0.03:
            st, note = "⚠", "跌破 MA20 较深"
        elif pct > 0.20:
            st, note = "⚠", "距 MA20 过远，过热风险"
        else:
            st, note = "→", ""
    else:  # MA60
        if 0.05 <= pct <= 0.30:
            st, note = "✅", "在 MA60 上方健康区间"
        elif pct < 0:
            st, note = "❌", "跌破 MA60，趋势警戒"
        elif pct > 0.50:
            st, note = "⚠", "距 MA60 过远"
        else:
            st, note = "→", ""
    return {"value": val, "status": st, "note": note or f"距 MA{ma_period} {val}%"}


def _f_price_to_extreme(df: pd.DataFrame, lookback: int = 250, kind: str = "high") -> dict:
    close = df["close"]
    if len(close) < lookback:
        lookback = len(close)
    window = close.iloc[-lookback:]
    if kind == "high":
        ext = window.max()
        pct = (close.iloc[-1] - ext) / ext
        val = round(pct * 100, 1)
        if -0.25 <= pct <= -0.05:
            st, note = "✅", f"距 52 周高 {val}%（健康回撤区间）"
        elif pct >= -0.05:
            st, note = "✅", f"距 52 周高仅 {val}%（接近新高）"
        else:
            st, note = "⚠", f"距 52 周高 {val}%（偏远）"
    else:
        ext = window.min()
        pct = (close.iloc[-1] - ext) / ext
        val = round(pct * 100, 1)
        if pct >= 0.30:
            st, note = "✅", f"距 52 周低 +{val}%（明显反弹）"
        else:
            st, note = "⚠", f"距 52 周低 +{val}%（仍接近底部）"
    return {"value": val, "status": st, "note": note}


def _f_consec_up_days(df: pd.DataFrame) -> dict:
    close = df["close"]
    n = 0
    for i in range(len(close) - 1, 0, -1):
        if close.iloc[i] > close.iloc[i - 1]:
            n += 1
        else:
            break
    if 1 <= n <= 4:
        st, note = "✅", "连涨 1-4 日，正常"
    elif n >= 7:
        st, note = "⚠", "连涨 ≥7 日，过热风险"
    elif n == 0:
        st, note = "→", "今日未上涨"
    else:
        st, note = "→", ""
    return {"value": n, "status": st, "note": note}


def _f_vol_ratio(df: pd.DataFrame, short: int = 5, long_: int = 20) -> dict:
    if "volume" not in df or len(df) < long_:
        return {"value": None, "status": "?", "note": "无成交量或样本不足"}
    s = df["volume"].rolling(short).mean().iloc[-1]
    l = df["volume"].rolling(long_).mean().iloc[-1]
    if l == 0 or pd.isna(l):
        return {"value": None, "status": "?", "note": "数据异常"}
    ratio = round(s / l, 2)
    if 1.0 <= ratio <= 1.5:
        st, note = "✅", "温和放量"
    elif ratio > 2.5:
        st, note = "⚠", "异动放量"
    elif ratio < 0.6:
        st, note = "⚠", "明显缩量"
    else:
        st, note = "→", ""
    return {"value": ratio, "status": st, "note": note}


def _f_vol_price_consistency(df: pd.DataFrame, lookback: int = 5) -> dict:
    """量价同向率：correlation of (price change) and (volume change) over lookback."""
    if len(df) < lookback + 1:
        return {"value": None, "status": "?", "note": "样本不足"}
    pchg = df["close"].pct_change().iloc[-lookback:]
    vchg = df["volume"].pct_change().iloc[-lookback:]
    consistency = ((pchg > 0) == (vchg > 0)).astype(int).mean() * 2 - 1  # -1 to +1
    val = round(consistency, 2)
    if consistency > 0.5:
        st, note = "✅", "量价同向（健康）"
    elif consistency < -0.3:
        st, note = "⚠", "量价背离（警戒）"
    else:
        st, note = "→", ""
    return {"value": val, "status": st, "note": note}


def _f_turnover_pctl(df: pd.DataFrame, lookback: int = 60) -> dict:
    """Today's turnover_rate as percentile within last `lookback` days."""
    col = next((c for c in ("turnover", "换手率", "turnover_rate") if c in df.columns), None)
    if col is None or len(df) < lookback:
        return {"value": None, "status": "?", "note": "无换手率字段或样本不足"}
    window = df[col].iloc[-lookback:]
    today = df[col].iloc[-1]
    pctl = (window < today).mean() * 100
    val = round(pctl, 0)
    if 30 <= pctl <= 80:
        st, note = "✅", "换手率分位适中"
    elif pctl > 90:
        st, note = "⚠", "换手率过热（>90%分位）"
    elif pctl < 10:
        st, note = "⚠", "换手率冷清（<10%分位）"
    else:
        st, note = "→", ""
    return {"value": val, "status": st, "note": note}


def _f_rsi14(df: pd.DataFrame) -> dict:
    rsi = _rsi(df["close"], 14).iloc[-1]
    if pd.isna(rsi):
        return {"value": None, "status": "?", "note": "样本不足"}
    val = round(rsi, 1)
    if 40 <= rsi <= 70:
        st, note = "✅", "RSI 健康区间"
    elif rsi > 80:
        st, note = "⚠", "RSI 超买"
    elif rsi < 30:
        st, note = "⚠", "RSI 超卖"
    else:
        st, note = "→", ""
    return {"value": val, "status": st, "note": note}


def _f_macd_hist(df: pd.DataFrame) -> dict:
    _, _, hist = _macd(df["close"])
    last = hist.iloc[-1]
    prev = hist.iloc[-2] if len(hist) >= 2 else last
    if pd.isna(last):
        return {"value": None, "status": "?", "note": "样本不足"}
    val = round(last, 3)
    rising = last > prev
    if last > 0 and rising:
        st, note = "✅", "MACD 柱在零轴上方且上升"
    elif last > 0:
        st, note = "→", "MACD 柱在零轴上方但走平/下降"
    elif last < 0 and not rising:
        st, note = "❌", "MACD 柱在零轴下方且下降"
    else:
        st, note = "⚠", "MACD 柱在零轴下方但反弹中"
    return {"value": val, "status": st, "note": note}


def _f_macd_hist_sign_change_age(df: pd.DataFrame) -> dict:
    _, _, hist = _macd(df["close"])
    if len(hist.dropna()) < 5:
        return {"value": None, "status": "?", "note": "样本不足"}
    sign = np.sign(hist.dropna())
    last_sign = sign.iloc[-1]
    age = 0
    for i in range(len(sign) - 1, 0, -1):
        if sign.iloc[i] == last_sign:
            age += 1
        else:
            break
    if age < 10:
        st, note = "✅" if last_sign > 0 else "→", f"MACD 柱当前方向已持续 {age} 日"
    else:
        st, note = "→", f"MACD 柱方向已持续 {age} 日（趋势成熟）"
    return {"value": age, "status": st, "note": note}


def _f_macd_divergence(df: pd.DataFrame, lookback: int = 30) -> dict:
    """Top/bottom divergence detection (simple version)."""
    close = df["close"]
    _, _, hist = _macd(close)
    if len(close) < lookback:
        return {"value": "none", "status": "→", "note": "样本不足"}
    px_window = close.iloc[-lookback:]
    hist_window = hist.iloc[-lookback:]
    px_high_idx = px_window.idxmax()
    px_low_idx = px_window.idxmin()
    if px_high_idx == px_window.index[-1] and hist_window.iloc[-1] < hist_window.max() * 0.7:
        return {"value": "top", "status": "⚠", "note": "顶背离（价新高 + MACD 柱未新高）"}
    if px_low_idx == px_window.index[-1] and hist_window.iloc[-1] > hist_window.min() * 0.7:
        return {"value": "bottom", "status": "✅", "note": "底背离（价新低 + MACD 柱未新低，反转信号）"}
    return {"value": "none", "status": "→", "note": "无明显背离"}


def _f_kdj_state(df: pd.DataFrame) -> dict:
    k, d, j = _kdj(df["high"], df["low"], df["close"])
    last_k, last_d = k.iloc[-1], d.iloc[-1]
    prev_k, prev_d = k.iloc[-2], d.iloc[-2]
    if pd.isna(last_k):
        return {"value": None, "status": "?", "note": "样本不足"}
    cross_up = (prev_k <= prev_d) and (last_k > last_d)
    cross_dn = (prev_k >= prev_d) and (last_k < last_d)
    if cross_up and last_k < 30:
        return {"value": "golden_low", "status": "✅", "note": "低位金叉（强买信号）"}
    if cross_dn and last_k > 70:
        return {"value": "death_high", "status": "❌", "note": "高位死叉（强卖信号）"}
    if last_k < 20:
        return {"value": "low", "status": "→", "note": "KDJ 在低位"}
    if last_k > 80:
        return {"value": "high", "status": "⚠", "note": "KDJ 在高位"}
    return {"value": "mid", "status": "→", "note": "KDJ 在中位"}


def _f_boll_position(df: pd.DataFrame) -> dict:
    ma, upper, lower = _boll(df["close"], 20, 2.0)
    last = df["close"].iloc[-1]
    u, l = upper.iloc[-1], lower.iloc[-1]
    if pd.isna(u) or u == l:
        return {"value": None, "status": "?", "note": "样本不足"}
    pos = (last - l) / (u - l)
    val = round(pos, 2)
    if 0.4 <= pos <= 0.7:
        st, note = "✅", "在布林带中部"
    elif pos > 0.9:
        st, note = "⚠", "贴近布林带上轨"
    elif pos < 0.1:
        st, note = "⚠", "贴近布林带下轨"
    else:
        st, note = "→", ""
    return {"value": val, "status": st, "note": note}


def _f_boll_band_width_pctl(df: pd.DataFrame, lookback: int = 60) -> dict:
    ma, upper, lower = _boll(df["close"], 20, 2.0)
    width = (upper - lower) / ma
    if len(width.dropna()) < lookback:
        return {"value": None, "status": "?", "note": "样本不足"}
    today = width.iloc[-1]
    pctl = (width.iloc[-lookback:] < today).mean() * 100
    val = round(pctl, 0)
    if 30 <= pctl <= 70:
        st, note = "→", "布林带宽中性"
    elif pctl < 15:
        st, note = "⚠", "布林带极度收敛（突破在即）"
    elif pctl > 85:
        st, note = "⚠", "布林带极度扩张（情绪极端）"
    else:
        st, note = "→", ""
    return {"value": val, "status": st, "note": note}


def _f_atr14_pct(df: pd.DataFrame) -> dict:
    atr = _atr(df["high"], df["low"], df["close"], 14).iloc[-1]
    if pd.isna(atr):
        return {"value": None, "status": "?", "note": "样本不足"}
    pct = atr / df["close"].iloc[-1] * 100
    val = round(pct, 2)
    if 1.5 <= pct <= 4:
        st, note = "✅", "ATR/价 在正常区间"
    elif pct > 6:
        st, note = "⚠", "波动剧烈"
    else:
        st, note = "→", ""
    return {"value": val, "status": st, "note": note}


def _f_pattern_basic(df: pd.DataFrame) -> dict:
    """Basic 4 K-line patterns at the latest bar."""
    if len(df) < 3:
        return {"value": "none", "status": "→", "note": "样本不足"}
    o, h, l, c = (df[col].iloc[-1] for col in ("open", "high", "low", "close"))
    o2, c2 = df["open"].iloc[-2], df["close"].iloc[-2]
    body = abs(c - o)
    upper_shadow = h - max(o, c)
    lower_shadow = min(o, c) - l
    range_ = h - l if h != l else 1e-9

    # Hammer: small body, long lower shadow, at recent low
    if body / range_ < 0.3 and lower_shadow / range_ > 0.5:
        recent_low = df["low"].iloc[-10:].min()
        if abs(l - recent_low) / recent_low < 0.02:
            return {"value": "hammer", "status": "✅", "note": "锤子线（可能反转信号）"}
    # Bullish engulfing
    if c2 < o2 and c > o and o < c2 and c > o2:
        return {"value": "engulfing_bullish", "status": "✅", "note": "看涨吞没形态"}
    # Bearish engulfing
    if c2 > o2 and c < o and o > c2 and c < o2:
        return {"value": "engulfing_bearish", "status": "❌", "note": "看跌吞没形态"}
    # Doji
    if body / range_ < 0.05:
        return {"value": "doji_at_extreme", "status": "⚠", "note": "十字星（犹豫）"}
    return {"value": "none", "status": "→", "note": "无明显形态"}


def _f_pivot_breakout(df: pd.DataFrame) -> dict:
    """Minervini-style pivot breakout: consolidation → breakout on volume."""
    if len(df) < 20:
        return {"value": "none", "status": "→", "note": "样本不足"}
    close = df["close"]
    high = df["high"]
    vol = df.get("volume")
    last_5 = high.iloc[-15:-5].max()  # pivot from days [-15, -5]
    last_close = close.iloc[-1]
    avg_vol_20 = vol.iloc[-20:].mean() if vol is not None else None
    today_vol = vol.iloc[-1] if vol is not None else None

    if last_close > last_5 * 1.02:
        if today_vol is not None and avg_vol_20 is not None and today_vol > avg_vol_20 * 1.5:
            return {"value": "breakout", "status": "✅", "note": "Pivot 突破，量能配合"}
        else:
            return {"value": "breakout_failed", "status": "⚠", "note": "突破但量能未配合"}
    if last_close > last_5 * 0.97:
        return {"value": "building_base", "status": "→", "note": "在 pivot 附近震荡构筑平台"}
    return {"value": "none", "status": "→", "note": "无 pivot 信号"}


# --------------------------------------------------------------------------
# Top-level computer
# --------------------------------------------------------------------------

# Map factor name -> (computer fn, requires_weekly: bool)
FACTOR_REGISTRY = {
    # A. Stage
    "weinstein_stage":        (_f_weinstein_stage, True),
    "MA20_slope_5d":          (lambda df, _: _f_ma_slope(df, 20, 5), False),
    "MA60_slope_20d":         (lambda df, _: _f_ma_slope(df, 60, 20), False),
    "MA_alignment_daily":     (lambda df, _: _f_ma_alignment(df), False),
    # B. Position
    "price_vs_MA20_pct":      (lambda df, _: _f_price_vs_ma(df, 20), False),
    "price_vs_MA60_pct":      (lambda df, _: _f_price_vs_ma(df, 60), False),
    "price_to_52w_high_pct":  (lambda df, _: _f_price_to_extreme(df, 250, "high"), False),
    "price_to_52w_low_pct":   (lambda df, _: _f_price_to_extreme(df, 250, "low"), False),
    "consec_up_days":         (lambda df, _: _f_consec_up_days(df), False),
    # C. Volume-Price
    "vol_ratio_5_20":         (lambda df, _: _f_vol_ratio(df, 5, 20), False),
    "vol_price_consistency_5d": (lambda df, _: _f_vol_price_consistency(df, 5), False),
    "turnover_pct_60d":       (lambda df, _: _f_turnover_pctl(df, 60), False),
    # D. Momentum
    "RSI14_daily":            (lambda df, _: _f_rsi14(df), False),
    "MACD_hist_daily":        (lambda df, _: _f_macd_hist(df), False),
    "MACD_hist_sign_change_age": (lambda df, _: _f_macd_hist_sign_change_age(df), False),
    "MACD_divergence":        (lambda df, _: _f_macd_divergence(df), False),
    "KDJ_state":              (lambda df, _: _f_kdj_state(df), False),
    # E. Volatility & Strength
    "BOLL_position_20d":      (lambda df, _: _f_boll_position(df), False),
    "BOLL_band_width_pctl_60d": (lambda df, _: _f_boll_band_width_pctl(df, 60), False),
    "ATR14_pct":              (lambda df, _: _f_atr14_pct(df), False),
    # F. Patterns
    "pattern_basic":          (lambda df, _: _f_pattern_basic(df), False),
    "pivot_breakout_state":   (lambda df, _: _f_pivot_breakout(df), False),
    # Note: RS_vs_sector_*, sector_RS_rank_in_market, MA_alignment_weekly require
    # extra inputs (sector index data); they're handled in compute_factors() below.
}


def _resample_to_weekly(df: pd.DataFrame) -> pd.DataFrame:
    """Resample daily OHLCV to weekly (Friday close). Assumes df has a date index or 'date' col."""
    if "date" in df.columns:
        d = df.copy()
        d.index = pd.to_datetime(d["date"])
    else:
        d = df.copy()
        d.index = pd.to_datetime(d.index)
    rule = "W-FRI"
    weekly = d.resample(rule).agg({
        "open": "first", "high": "max", "low": "min", "close": "last",
        "volume": "sum",
    }).dropna()
    return weekly


def _normalize_ohlcv_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Map AKShare Chinese / various column names to standard names."""
    d = df.copy()
    aliases = {
        "日期": "date", "开盘": "open", "收盘": "close", "最高": "high", "最低": "low",
        "成交量": "volume", "成交额": "amount", "换手率": "turnover",
        "振幅": "amplitude", "涨跌幅": "pct_change", "涨跌额": "change",
    }
    d = d.rename(columns=aliases)
    return d


def compute_factors(symbol: str, market: Optional[str] = None,
                     period: str = "daily", days: int = 300,
                     factors: Optional[list[str]] = None,
                     sector_df: Optional[pd.DataFrame] = None) -> dict:
    """Compute named factors for a symbol.

    Returns:
        {"ok": True, "symbol": ..., "as_of": ..., "factors": {name: {value, status, note}}}
    """
    # Lazy import to avoid circular
    from scripts.akshare_helpers import fetch_ohlcv, normalize_symbol

    sym = normalize_symbol(symbol, market)
    raw = fetch_ohlcv(symbol, market, period=period, days=days)
    if not raw.get("ok"):
        return {"ok": False, "error": raw.get("error"), "symbol": symbol}
    df = pd.DataFrame(raw["data"])
    if df.empty:
        return {"ok": False, "error": "empty OHLCV data", "symbol": symbol}
    df = _normalize_ohlcv_columns(df)
    # Coerce numeric columns
    for c in ("open", "high", "low", "close", "volume", "turnover"):
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    weekly = _resample_to_weekly(df) if period == "daily" else None

    selected = factors or list(FACTOR_REGISTRY.keys())
    out = {}
    for name in selected:
        if name not in FACTOR_REGISTRY:
            out[name] = {"value": None, "status": "?", "note": "未知因子"}
            continue
        fn, _ = FACTOR_REGISTRY[name]
        try:
            out[name] = fn(df, weekly)
        except Exception as e:
            out[name] = {"value": None, "status": "?", "note": f"计算异常: {e}"}

    return {
        "ok": True,
        "symbol": sym.to_dict(),
        "as_of": str(df.iloc[-1].get("date", "?")) if "date" in df.columns else "?",
        "n_bars": len(df),
        "factors": out,
    }


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(prog="ta_factors", description="M2 named factor computer")
    p.add_argument("--symbol", required=True)
    p.add_argument("--market", choices=["A", "HK"], default=None)
    p.add_argument("--period", default="daily")
    p.add_argument("--days", type=int, default=300)
    p.add_argument("--factors", default=None, help="comma-separated factor names; default all")
    args = p.parse_args()
    factors = args.factors.split(",") if args.factors else None
    result = compute_factors(args.symbol, args.market, args.period, args.days, factors)
    print(json.dumps(result, ensure_ascii=False, default=str, indent=2))


if __name__ == "__main__":
    main()
