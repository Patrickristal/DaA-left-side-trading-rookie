"""
trend_integrity.py — M1 趋势完整性监测器 (Trend Integrity Monitor).

Loads active theses from memory_store, evaluates each registered
trend_break_trigger against current data, and outputs the ✅✅❌✅ status
grid that M1 displays in 你的雷达 section.

This is the **physical implementation** of SKILL.md core principle 3:
"Trend integrity 监测，不强制纪律 — 事实给到，决策权交还给 Patrick"

Trigger schema (registered at M4 论点登记 time)
================================================
Each trigger in `active_theses.jsonl` should be a dict like:

    {
        "id": "trig_1",
        "description": "板块 RS 跌出全市场前 30%",
        "type": "rs_rank" | "fund_flow" | "ma_break" | "factor" |
                "lhb_seat" | "policy" | "manual",
        "params": {...},          # type-specific parameters
        "operator": "lt" | "gt" | "lte" | "gte" | "eq" | "ne",
        "threshold": <numeric|str>
    }

Supported trigger types
=======================
  - "factor"     — any of the 25 named factors from ta_factors.py
                   params: {symbol, factor_name, market}
  - "ma_break"   — price closing below a specified MA
                   params: {symbol, ma_period, market}
  - "fund_flow"  — bucket cumulative net flow over N days
                   params: {target, target_type, market, bucket: 北向|主力|融资,
                            window_days, metric: amount|velocity_z}
  - "rs_rank"    — sector rank within market
                   params: {sector_name, threshold_rank}
  - "lhb_seat"   — known hot-money seat appearance
                   params: {symbol, days, seat_label}
  - "policy"     — manual flag for policy-event triggers (no auto-check;
                   marks as "needs human review")
  - "manual"     — purely manual; always marked "unknown"

If a trigger is unknown / has no params / can't be evaluated, status is
"unknown" — never silently passes or fails.

Usage:
    from scripts.trend_integrity import check_thesis, check_all_active

    check_all_active()  # checks every active thesis, returns aggregate report
    check_thesis("thesis_20260501_haiyang")  # single thesis

CLI:
    python -m scripts.trend_integrity check-all
    python -m scripts.trend_integrity check-one --thesis-id thesis_20260501_haiyang
"""
from __future__ import annotations

import argparse
import json
import sys
from typing import Optional


# --------------------------------------------------------------------------
# Status symbols
# --------------------------------------------------------------------------

S_OK = "✅"
S_BROKEN = "❌"
S_WARN = "⚠"
S_UNKNOWN = "?"


# --------------------------------------------------------------------------
# Operator helpers
# --------------------------------------------------------------------------

def _compare(value, operator: str, threshold) -> bool:
    """Return True if (value <op> threshold). Returns False on type error."""
    try:
        if operator == "lt":  return value < threshold
        if operator == "gt":  return value > threshold
        if operator == "lte": return value <= threshold
        if operator == "gte": return value >= threshold
        if operator == "eq":  return value == threshold
        if operator == "ne":  return value != threshold
    except TypeError:
        return False
    return False


# --------------------------------------------------------------------------
# Trigger evaluators (one per type)
# --------------------------------------------------------------------------

def _eval_factor(trigger: dict) -> dict:
    """Check a named TA factor against threshold."""
    p = trigger.get("params", {})
    symbol = p.get("symbol")
    factor = p.get("factor_name")
    market = p.get("market", "A")
    if not (symbol and factor):
        return {"status": S_UNKNOWN, "reason": "missing symbol or factor_name"}
    try:
        from scripts.ta_factors import compute_factors
        result = compute_factors(symbol, market, factors=[factor])
        if not result.get("ok"):
            return {"status": S_UNKNOWN, "reason": result.get("error")}
        f = result["factors"].get(factor, {})
        value = f.get("value")
        if value is None:
            return {"status": S_UNKNOWN, "reason": "factor value None"}
        op = trigger.get("operator", "lt")
        thresh = trigger.get("threshold")
        broken = _compare(value, op, thresh)
        return {
            "status": S_BROKEN if broken else S_OK,
            "current_value": value,
            "threshold": thresh,
            "operator": op,
            "factor_status": f.get("status"),
            "factor_note": f.get("note"),
        }
    except Exception as e:
        return {"status": S_UNKNOWN, "reason": f"{type(e).__name__}: {e}"}


def _eval_ma_break(trigger: dict) -> dict:
    """Check whether close < MA(period)."""
    p = trigger.get("params", {})
    symbol = p.get("symbol")
    period = p.get("ma_period", 60)
    market = p.get("market", "A")
    factor_name = f"price_vs_MA{period}_pct" if period in (20, 60) else None
    if not factor_name:
        return {"status": S_UNKNOWN, "reason": f"unsupported ma_period {period}"}
    return _eval_factor({
        "params": {"symbol": symbol, "factor_name": factor_name, "market": market},
        "operator": "lt",
        "threshold": 0,  # below MA = broken
    })


def _eval_fund_flow(trigger: dict) -> dict:
    """Check fund flow metric against threshold."""
    p = trigger.get("params", {})
    target = p.get("target")
    ttype = p.get("target_type", "stock")
    market = p.get("market", "A")
    bucket = p.get("bucket", "北向")
    metric = p.get("metric", "amount")
    op = trigger.get("operator", "lt")
    thresh = trigger.get("threshold")
    if not target:
        return {"status": S_UNKNOWN, "reason": "missing target"}
    try:
        from scripts.fund_flow import compute_three_bucket_grid
        grid = compute_three_bucket_grid(target, ttype, market)
        row = next((r for r in grid["grid"] if r.get("bucket") == bucket), None)
        if not row:
            return {"status": S_UNKNOWN, "reason": f"bucket {bucket} not found"}
        if metric == "velocity_z":
            value = row.get("velocity_z")
        elif metric == "amount_5d":
            value = row.get("amount_5d_yi")
        elif metric == "amount_20d":
            value = row.get("amount_20d_yi")
        else:
            return {"status": S_UNKNOWN, "reason": f"unknown metric {metric}"}
        if value is None:
            return {"status": S_UNKNOWN, "reason": "metric value None"}
        broken = _compare(value, op, thresh)
        return {
            "status": S_BROKEN if broken else S_OK,
            "current_value": value,
            "threshold": thresh,
            "operator": op,
            "bucket": bucket,
            "metric": metric,
        }
    except Exception as e:
        return {"status": S_UNKNOWN, "reason": f"{type(e).__name__}: {e}"}


def _eval_rs_rank(trigger: dict) -> dict:
    """Check sector RS rank within all market sectors."""
    p = trigger.get("params", {})
    sector = p.get("sector_name")
    if not sector:
        return {"status": S_UNKNOWN, "reason": "missing sector_name"}
    try:
        from scripts.akshare_helpers import fetch_industry_boards
        boards = fetch_industry_boards()
        if not boards.get("ok"):
            return {"status": S_UNKNOWN, "reason": boards.get("error")}
        import pandas as pd
        df = pd.DataFrame(boards["data"])
        pct_col = next((c for c in df.columns if "涨跌幅" in c), None)
        name_col = next((c for c in df.columns if "板块名称" in c or "名称" in c), None)
        if not (pct_col and name_col):
            return {"status": S_UNKNOWN, "reason": "missing 涨跌幅 or 名称 column"}
        df = df.sort_values(pct_col, ascending=False).reset_index(drop=True)
        match = df[df[name_col].astype(str).str.contains(sector)]
        if match.empty:
            return {"status": S_UNKNOWN, "reason": f"sector {sector} not in board list"}
        rank = match.index[0] + 1
        op = trigger.get("operator", "gt")
        thresh = trigger.get("threshold", 30)  # default: rank > 30 = broken
        broken = _compare(rank, op, thresh)
        return {
            "status": S_BROKEN if broken else S_OK,
            "current_rank": int(rank),
            "threshold_rank": thresh,
            "operator": op,
            "total_sectors": len(df),
        }
    except Exception as e:
        return {"status": S_UNKNOWN, "reason": f"{type(e).__name__}: {e}"}


def _eval_lhb_seat(trigger: dict) -> dict:
    """Check 龙虎榜 famous seat appearance / disappearance."""
    p = trigger.get("params", {})
    symbol = p.get("symbol")
    days = p.get("days", 5)
    if not symbol:
        return {"status": S_UNKNOWN, "reason": "missing symbol"}
    try:
        from scripts.rs_ranker import _get_lhb_appearances
        result = _get_lhb_appearances(symbol, days=days)
        # Trigger is "broken" if no famous hotmoney appears (default)
        # Trigger could also be "broken if disappeared" — captured by operator
        n_famous = len(result.get("famous_hotmoney", [])) + len(result.get("famous_institutional", []))
        op = trigger.get("operator", "eq")
        thresh = trigger.get("threshold", 0)
        broken = _compare(n_famous, op, thresh)
        return {
            "status": S_BROKEN if broken else S_OK,
            "famous_seats_count": n_famous,
            "famous_hotmoney": result.get("famous_hotmoney"),
            "famous_institutional": result.get("famous_institutional"),
            "appearances_total": result.get("appearances"),
        }
    except Exception as e:
        return {"status": S_UNKNOWN, "reason": f"{type(e).__name__}: {e}"}


def _eval_policy(trigger: dict) -> dict:
    """Policy triggers can't be auto-checked; flag for human review."""
    return {
        "status": S_WARN,
        "reason": "Policy trigger requires human review — check news/policy sources manually",
        "description": trigger.get("description"),
    }


def _eval_manual(trigger: dict) -> dict:
    return {
        "status": S_UNKNOWN,
        "reason": "Manual trigger — Patrick to verify",
        "description": trigger.get("description"),
    }


TRIGGER_EVALUATORS = {
    "factor":    _eval_factor,
    "ma_break":  _eval_ma_break,
    "fund_flow": _eval_fund_flow,
    "rs_rank":   _eval_rs_rank,
    "lhb_seat":  _eval_lhb_seat,
    "policy":    _eval_policy,
    "manual":    _eval_manual,
}


# --------------------------------------------------------------------------
# Top-level
# --------------------------------------------------------------------------

def check_thesis(thesis_id: str) -> dict:
    """Evaluate every trigger in a single thesis."""
    from scripts.memory_store import query_active_theses
    theses = query_active_theses(active_only=False)
    target = next((t for t in theses if t.get("thesis_id") == thesis_id), None)
    if not target:
        return {"ok": False, "error": f"thesis {thesis_id} not found"}

    triggers = target.get("trend_break_triggers", [])
    if isinstance(triggers, list) and triggers and isinstance(triggers[0], str):
        # Strings (legacy) — wrap as manual
        triggers = [{"id": f"trig_{i}", "description": d, "type": "manual"}
                    for i, d in enumerate(triggers)]

    results = []
    n_ok = n_broken = n_unknown = 0
    for trig in triggers:
        ttype = trig.get("type", "manual")
        evaluator = TRIGGER_EVALUATORS.get(ttype, _eval_manual)
        result = evaluator(trig)
        result["id"] = trig.get("id")
        result["description"] = trig.get("description")
        result["type"] = ttype
        results.append(result)
        st = result["status"]
        if st == S_OK:        n_ok += 1
        elif st == S_BROKEN:  n_broken += 1
        else:                 n_unknown += 1

    grid_string = "".join(r["status"] for r in results)
    overall = (
        "all_healthy" if n_broken == 0 and n_unknown == 0 else
        "any_broken" if n_broken > 0 else
        "needs_review"
    )
    return {
        "ok": True,
        "thesis_id": thesis_id,
        "claim": target.get("claim"),
        "symbols": target.get("symbols", []),
        "n_triggers": len(results),
        "n_ok": n_ok,
        "n_broken": n_broken,
        "n_unknown": n_unknown,
        "grid_string": grid_string,
        "overall": overall,
        "triggers": results,
    }


def check_all_active() -> dict:
    """Run integrity check across all active theses."""
    from scripts.memory_store import query_active_theses
    theses = query_active_theses(active_only=True)
    if not theses:
        return {"ok": True, "n_theses": 0, "message": "No active theses to monitor"}

    reports = []
    for t in theses:
        tid = t.get("thesis_id")
        if not tid:
            continue
        reports.append(check_thesis(tid))

    n_with_breaks = sum(1 for r in reports if r.get("n_broken", 0) > 0)
    return {
        "ok": True,
        "n_theses": len(reports),
        "n_with_breaks": n_with_breaks,
        "summary": (
            f"{n_with_breaks}/{len(reports)} 个论点出现 trigger 破损 ⚠"
            if n_with_breaks else
            f"全部 {len(reports)} 个论点 trigger 健康 ✅"
        ),
        "reports": reports,
    }


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(prog="trend_integrity", description="M1 trend integrity monitor")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("check-all", help="Check all active theses")
    p_one = sub.add_parser("check-one", help="Check a single thesis")
    p_one.add_argument("--thesis-id", required=True)
    args = p.parse_args()
    if args.cmd == "check-all":
        result = check_all_active()
    elif args.cmd == "check-one":
        result = check_thesis(args.thesis_id)
    print(json.dumps(result, ensure_ascii=False, default=str, indent=2))


if __name__ == "__main__":
    main()
