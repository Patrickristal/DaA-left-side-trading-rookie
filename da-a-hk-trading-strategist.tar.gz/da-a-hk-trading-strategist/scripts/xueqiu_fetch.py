"""
xueqiu_fetch.py — 雪球关注度 / 讨论度抓取 (sentiment auxiliary).

Provides community-scraper fallback to fetch Xueqiu sentiment metrics for a
stock as a *cross-validation* signal in M6 — never as primary.

Why a stub layer
================
Xueqiu has no official open API. Community scrapers exist (e.g. xueqiu-api on
GitHub) but they:
  - Require fresh cookies (often `xq_a_token`, `xqat`, `xq_r_token`)
  - Are routinely broken by Xueqiu's CSRF / rate-limit changes
  - Often need IP rotation in production

This module is intentionally **degraded by default**: it tries a public quote
endpoint that doesn't require login. If the call fails (no cookies / rate-
limit / endpoint changed), it returns a graceful "ok=False, reason" envelope
so M6 / M4 can simply skip the Xueqiu cross-check rather than crash.

Patrick: when you're ready to enable full sentiment scraping:
  1. Set env var XUEQIU_COOKIE = "xq_a_token=...; xqat=...; xq_r_token=..."
  2. Optionally install `requests` (already in stdlib via urllib but requests
     is friendlier).

Usage:
    from scripts.xueqiu_fetch import fetch_hotness
    h = fetch_hotness("00700")  # HK 腾讯
    h = fetch_hotness("SH600519")  # A 茅台

CLI:
    python -m scripts.xueqiu_fetch --symbol 00700 --market HK
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from typing import Optional


XUEQIU_QUOTE_URL = "https://stock.xueqiu.com/v5/stock/quote.json"
XUEQIU_TIMELINE_URL = "https://stock.xueqiu.com/v5/stock/quote/comment/list.json"

DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
    ),
    "Accept": "application/json, text/plain, */*",
    "Referer": "https://xueqiu.com/",
}


def _xueqiu_symbol(symbol: str, market: Optional[str]) -> str:
    """Format symbol for Xueqiu API.
       A-share: SH600519 / SZ300750
       HK:      00700  (no prefix)
       US:      AAPL"""
    s = symbol.strip().upper()
    if market and market.upper() == "HK":
        # strip leading "HK" if present, keep digits
        s = s.lstrip("HK").lstrip("0")
        return s.zfill(5)
    if market and market.upper() == "A":
        # ensure prefix
        if s.startswith(("SH", "SZ", "BJ")):
            return s
        if s.startswith(("60", "688", "900")):
            return f"SH{s}"
        if s.startswith(("00", "30", "200")):
            return f"SZ{s}"
        if s.startswith(("4", "8")):
            return f"BJ{s}"
    return s


def _http_get(url: str, params: dict, cookies: Optional[str] = None,
              timeout: float = 8.0) -> dict:
    """Minimal HTTP GET using stdlib urllib. Returns parsed JSON or error envelope."""
    try:
        import urllib.parse, urllib.request
    except ImportError:
        return {"ok": False, "error": "urllib not available"}

    qs = urllib.parse.urlencode(params)
    full_url = f"{url}?{qs}"
    req = urllib.request.Request(full_url, headers=dict(DEFAULT_HEADERS))
    if cookies:
        req.add_header("Cookie", cookies)

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8", errors="replace")
        return {"ok": True, "data": json.loads(body)}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def fetch_hotness(symbol: str, market: Optional[str] = None) -> dict:
    """Try to fetch Xueqiu hotness / follower count for a symbol.

    Returns:
        {
            "ok": bool,
            "symbol": <xueqiu format>,
            "follower_count": int | None,    # 关注度
            "comment_count_24h": int | None, # 讨论热度（最近 24 小时）
            "tweet_count": int | None,       # 推文总数
            "reason": str (if ok=False)
        }
    """
    xq_sym = _xueqiu_symbol(symbol, market)
    cookies = os.environ.get("XUEQIU_COOKIE", "")

    # Try the public quote endpoint first
    quote_result = _http_get(
        XUEQIU_QUOTE_URL,
        {"symbol": xq_sym, "extend": "detail"},
        cookies=cookies,
    )

    if not quote_result.get("ok"):
        return {
            "ok": False,
            "symbol": xq_sym,
            "reason": f"HTTP error: {quote_result.get('error')}",
            "fallback_action": "skip Xueqiu cross-check",
        }

    body = quote_result["data"]
    if body.get("error_code") and body["error_code"] != 0:
        # Likely needs cookies
        return {
            "ok": False,
            "symbol": xq_sym,
            "reason": f"Xueqiu API error: {body.get('error_description', 'unknown')}",
            "fallback_action": "set XUEQIU_COOKIE env var with fresh xq_a_token",
        }

    # Extract metrics — schema may vary
    quote = (body.get("data") or {}).get("quote") or {}
    follower = quote.get("followers") or quote.get("follower_count")
    tweet_count = quote.get("tweet_count") or quote.get("total_tweet_count")
    comment_24h = quote.get("comment_count_24h")

    return {
        "ok": True,
        "symbol": xq_sym,
        "follower_count": follower,
        "comment_count_24h": comment_24h,
        "tweet_count": tweet_count,
        "raw_quote_keys": list(quote.keys())[:30],  # for debugging schema drift
        "note": "Xueqiu data is unofficial scraping; treat as soft signal",
    }


def fetch_hotness_batch(symbols: list[str], market: Optional[str] = None,
                          delay_s: float = 0.5) -> list[dict]:
    """Fetch hotness for multiple symbols with throttling."""
    results = []
    for s in symbols:
        results.append(fetch_hotness(s, market))
        time.sleep(delay_s)
    return results


def hotness_change_pct(symbol: str, market: Optional[str] = None,
                        prev_follower: Optional[int] = None) -> dict:
    """Compute follower count change vs a previous reading. Used for trend
    detection in M6 — 'sentiment 关注度上升' as cross-validation signal."""
    current = fetch_hotness(symbol, market)
    if not current.get("ok") or current.get("follower_count") is None:
        return {"ok": False, "reason": current.get("reason", "no data")}
    if prev_follower is None:
        return {"ok": True, "current_follower": current["follower_count"],
                "change_pct": None,
                "note": "no baseline provided; persist this snapshot for future delta"}
    cur = current["follower_count"]
    delta = (cur - prev_follower) / prev_follower if prev_follower else None
    return {
        "ok": True,
        "current_follower": cur,
        "previous_follower": prev_follower,
        "change_pct": round(delta * 100, 2) if delta is not None else None,
        "interpretation": (
            "明显上升（关注度增长）" if delta and delta > 0.10 else
            "温和上升" if delta and delta > 0.02 else
            "明显下降" if delta and delta < -0.10 else
            "稳定" if delta is not None else "n/a"
        ),
    }


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(prog="xueqiu_fetch", description="Xueqiu sentiment scraper (degraded fallback)")
    p.add_argument("--symbol", required=True)
    p.add_argument("--market", choices=["A", "HK", "US"], default=None)
    p.add_argument("--prev-follower", type=int, default=None)
    args = p.parse_args()
    if args.prev_follower is not None:
        result = hotness_change_pct(args.symbol, args.market, args.prev_follower)
    else:
        result = fetch_hotness(args.symbol, args.market)
    print(json.dumps(result, ensure_ascii=False, default=str, indent=2))


if __name__ == "__main__":
    main()
